import"./BdvrJao5.js";const s=globalThis.setInterval;export{s};
