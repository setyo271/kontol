// config.js
export default {
  // ==================== MAIN BOT ====================
  MAIN_BOT: {
    TOKEN: 'ISI_TOKEN_BOT_UTAMA_KAMU_DI_SINI',
    USERNAME: '@EclipxxDeployBot'
  },

  // ==================== OPERATORS ====================
  // Daftar User ID yang punya akses admin panel
  OPERATORS: [
    '123456789',      // User ID operator 1
    '987654321'       // User ID operator 2
  ],

  // ==================== ADMIN SAWERIA ====================
  // Saweria untuk terima pembayaran DEPLOY (milik admin/operator)
  ADMIN_SAWERIA: {
    email: 'admin@eclipxx.com',
    password: 'AdminPassword123!',
    apikey: 'CahSepeleWongAdmin'    // API key dari neoxr.eu
  },

  // ==================== PRICING DEPLOY ====================
  PRICING: {
    response_per_1k: 150,         // Rp 150 per 1000 response  (0.15 per 1)
    day_rate: 150,                // Rp 150 per hari
    no_ads_fee: 3000,             // Rp 3000 jika tanpa iklan
    min_response: 1000,           // Minimal 1000 response
    min_days: 1                   // Minimal 1 hari
  },

  // ==================== API ENDPOINTS ====================
  API: {
    TELEGRAM: 'https://api.telegram.org',
    SAWERIA: 'https://api.neoxr.eu/api',
    DITZNESIA: 'https://api.jasaotp.id/v1'
  },

  // ==================== DATABASE ====================
  DATABASE: {
    PATH: './data/main.db'
  },

  // ==================== UPLOAD LIMITS ====================
  LIMITS: {
    COVER_MAX_SIZE: 5 * 1024 * 1024,  // 5 MB
    PHOTO_MAX_SIZE: 5 * 1024 * 1024   // 5 MB
  },

  // ==================== TIMEOUTS ====================
  TIMEOUT: {
    PAYMENT: 10 * 60 * 1000,       // 10 menit
    OTP_CONFIRM: 2 * 60 * 1000,    // 2 menit konfirmasi bayar
    OTP_WAIT: 10 * 60 * 1000,      // 10 menit tunggu OTP
    CHECK_INTERVAL: 5000            // 5 detik auto-check
  },

  // ==================== NOTIFICATIONS ====================
  NOTIFICATIONS: {
    EXPIRE_WARNING_DAYS: [3, 1],   // Kirim notif 3 hari & 1 hari sebelum expired
    LOW_LIMIT_PERCENT: 10,         // Notif jika limit < 10%
    NOTIFY_HOUR: 9                 // Jam berapa notif dikirim (format 24h)
  }
}
