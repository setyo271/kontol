# 🤖 EclipxxDeployBot

Bot Telegram untuk **deploy dan kelola bot lain** dengan sistem pembayaran QRIS via **Saweria** dan layanan OTP via **Ditznesia**.

---

## 📁 Struktur File

```
eclipxx-deploy-bot/
├── index.js              ← Entry point (jalankan ini)
├── config.js             ← Konfigurasi utama
├── package.json
├── data/
│   └── main.db           ← Database SQLite (auto-dibuat)
└── src/
    ├── mainBot.js        ← Handler bot utama (EclipxxDeployBot)
    ├── deployedBot.js    ← Handler bot yang sudah di-deploy
    ├── database.js       ← Database helper (SQLite)
    ├── saweria.js        ← Saweria API (login, payment, check)
    ├── ditznesia.js      ← Ditznesia API (OTP service)
    ├── telegram.js       ← Telegram API helper & utilities
    ├── paymentManager.js ← Auto-check pembayaran & OTP polling
    └── scheduler.js      ← Notifikasi expired & limit habis
```

---

## ⚙️ Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Edit `config.js`

```js
MAIN_BOT: {
  TOKEN: 'TOKEN_BOT_UTAMA_KAMU',   // ← Token @EclipxxDeployBot
  USERNAME: '@EclipxxDeployBot'
},

OPERATORS: [
  '123456789',   // ← User ID kamu (dapat dari @userinfobot)
],

ADMIN_SAWERIA: {
  email: 'email@saweria.co',       // ← Email Saweria kamu
  password: 'password123',         // ← Password Saweria
  apikey: 'APIKEY_NEOXR'          // ← API key dari neoxr.eu
},
```

### 3. Jalankan

```bash
node index.js
```

Atau dengan **PM2** (recommended untuk production):

```bash
npm install -g pm2
pm2 start index.js --name eclipxx-bot
pm2 save
pm2 startup
```

---

## 🚀 Cara Pakai

### Bot Utama (EclipxxDeployBot)

| Command | Deskripsi |
|---------|-----------|
| `/start` | Menu utama |
| `/deploy <token> <response> <hari> <iklan>` | Deploy bot baru |
| `/admin` | Panel admin (operator only) |

**Contoh deploy:**
```
/deploy 7891234:ABCDEF 10000 30 tidak
```
= 10.000 response, 30 hari, tanpa iklan

---

### Bot yang Sudah Di-Deploy (untuk Owner)

| Command | Deskripsi |
|---------|-----------|
| `/start` | Menu owner (jika owner) / Welcome user |
| `/setmsg <pesan>` | Ganti welcome message |
| `/loginsaweria <email> <pass>` | Login Saweria untuk terima pembayaran |
| `/setapikey <apikey>` | Setup API key Ditznesia untuk OTP |
| `/markup <nominal>` | Set profit OTP per order |
| `/cekotp <order_id>` | Cek OTP manual |

---

## 💰 Harga Deploy

| Item | Harga |
|------|-------|
| Response | Rp 150 per 1.000 |
| Durasi | Rp 150 per hari |
| Tanpa Iklan | +Rp 3.000 |

**Contoh:**
- 10.000 response + 30 hari + tanpa iklan
- = Rp 1.500 + Rp 4.500 + Rp 3.000
- = **Rp 9.000**

---

## 🔑 API yang Digunakan

### Saweria (Pembayaran QRIS)
- Login: `https://api.neoxr.eu/api/saweria`
- Create payment: `https://api.neoxr.eu/api/saweria-create`
- Check payment: `https://api.neoxr.eu/api/saweria-check`

> Daftar API key di: **neoxr.eu**

### Ditznesia (OTP Service)
- Balance: `https://api.jasaotp.id/v1/balance.php`
- Countries: `https://api.jasaotp.id/v1/negara.php`
- Services: `https://api.jasaotp.id/v1/layanan.php`
- Order: `https://api.jasaotp.id/v1/order.php`
- Check OTP: `https://api.jasaotp.id/v1/sms.php`
- Cancel: `https://api.jasaotp.id/v1/cancel.php`

> Daftar API key di: **ditznesia.id/daftar**

---

## ⚡ Fitur

### Bot Utama
- ✅ Deploy bot baru dengan validasi token
- ✅ Kalkulasi harga otomatis
- ✅ Pembayaran QRIS via Saweria
- ✅ Auto-check pembayaran tiap 5 detik
- ✅ Timeout invoice 10 menit
- ✅ Kelola bot (extend, delete)
- ✅ Admin panel (list bots, broadcast)
- ✅ Notifikasi expired (3 hari & 1 hari sebelum)
- ✅ Notifikasi limit hampir habis (< 10%)

### Bot yang Di-Deploy
- ✅ Welcome message kustom dengan variabel
- ✅ Cover foto/video
- ✅ Sistem produk dengan stok
- ✅ Notifikasi penjualan ke owner
- ✅ Layanan OTP multi-negara & operator
- ✅ Auto-check OTP masuk
- ✅ Markup profit OTP
- ✅ Rekap penjualan harian

---

## 🗄️ Database

Bot menggunakan **SQLite** (`data/main.db`) dengan tabel:

- `users` - Pengguna bot utama
- `deployed_bots` - Bot yang sudah di-deploy
- `products` - Produk di setiap bot
- `product_transactions` - Transaksi pembelian produk
- `otp_orders` - Order OTP
- `pending_payments` - Invoice yang belum dibayar
- `user_states` - State multi-step input user

---

## 🔧 Troubleshooting

**Bot tidak merespon:**
- Cek token di `config.js`
- Pastikan bot belum expired / limit habis
- Lihat log error di terminal

**Pembayaran tidak terdeteksi:**
- Pastikan Saweria user ID benar
- Cek saldo Saweria cukup
- Pastikan API key neoxr.eu valid

**OTP tidak masuk:**
- Cek saldo Ditznesia
- Coba nomor/operator lain
- Tunggu 5-10 menit

---

## 📞 Support

Hubungi admin jika ada masalah.
