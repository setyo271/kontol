// src/database.js
import Database from 'better-sqlite3'
import config from '../config.js'
import path from 'path'
import fs from 'fs'

// Pastikan folder data ada
const dbDir = path.dirname(config.DATABASE.PATH)
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true })

const db = new Database(config.DATABASE.PATH)

// ==================== PRAGMA ====================
db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')

// ==================== HELPER: ADD COLUMN IF MISSING ====================
// SQLite tidak support ALTER TABLE ADD COLUMN IF NOT EXISTS,
// jadi kita pakai try/catch
function addCol(table, col, type) {
  try {
    db.prepare(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`).run()
  } catch (_) { /* already exists, ignore */ }
}

// ==================== INIT TABLES ====================
db.exec(`
  -- Users tabel (pengguna bot utama)
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id TEXT UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Deployed bots
  CREATE TABLE IF NOT EXISTS deployed_bots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id TEXT NOT NULL,
    bot_token TEXT NOT NULL,
    bot_username TEXT NOT NULL,
    bot_id TEXT NOT NULL,
    response_limit INTEGER NOT NULL DEFAULT 0,
    response_used INTEGER DEFAULT 0,
    days INTEGER NOT NULL DEFAULT 1,
    expired_at DATETIME NOT NULL,
    has_ads INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    saweria_user_id TEXT,
    saweria_email TEXT,
    api_key TEXT,
    markup INTEGER DEFAULT 0,
    welcome_message TEXT DEFAULT 'Halo {mention} {greeting}! Selamat datang! 🎉',
    cover_file_id TEXT,
    cover_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Produk di deployed bot
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bot_id TEXT NOT NULL,
    name TEXT NOT NULL,
    price INTEGER NOT NULL,
    username TEXT,
    password TEXT,
    stock INTEGER DEFAULT 0,
    sold INTEGER DEFAULT 0,
    photo_file_id TEXT,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Transaksi produk
  CREATE TABLE IF NOT EXISTS product_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bot_id TEXT NOT NULL,
    product_id INTEGER NOT NULL,
    buyer_id TEXT NOT NULL,
    buyer_username TEXT,
    amount INTEGER NOT NULL,
    payment_id TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- OTP orders
  CREATE TABLE IF NOT EXISTS otp_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bot_id TEXT NOT NULL,
    buyer_id TEXT NOT NULL,
    buyer_username TEXT,
    order_id TEXT NOT NULL,
    number TEXT NOT NULL,
    country TEXT NOT NULL,
    service TEXT NOT NULL,
    operator TEXT NOT NULL,
    api_price INTEGER NOT NULL,
    sell_price INTEGER NOT NULL,
    profit INTEGER NOT NULL,
    payment_id TEXT,
    otp_code TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Pending payments
  CREATE TABLE IF NOT EXISTS pending_payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    user_id TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    message_id TEXT,
    photo_message_id TEXT,
    data TEXT NOT NULL,
    payment_id TEXT NOT NULL,
    saweria_user_id TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- User states (untuk handle multi-step input)
  CREATE TABLE IF NOT EXISTS user_states (
    telegram_id TEXT PRIMARY KEY,
    bot_context TEXT,
    state TEXT NOT NULL,
    data TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`)

// ==================== MIGRATIONS ====================
// Tambah kolom yang mungkin belum ada di database lama
// (aman dijalankan berkali-kali - error diabaikan jika kolom sudah ada)
addCol('deployed_bots', 'status', "TEXT DEFAULT 'active'")
addCol('deployed_bots', 'has_ads', 'INTEGER DEFAULT 1')
addCol('deployed_bots', 'saweria_user_id', 'TEXT')
addCol('deployed_bots', 'saweria_email', 'TEXT')
addCol('deployed_bots', 'api_key', 'TEXT')
addCol('deployed_bots', 'markup', 'INTEGER DEFAULT 0')
addCol('deployed_bots', 'welcome_message', "TEXT DEFAULT 'Halo {mention} {greeting}! Selamat datang!'")
addCol('deployed_bots', 'cover_file_id', 'TEXT')
addCol('deployed_bots', 'cover_type', 'TEXT')

// ==================== USER FUNCTIONS ====================
export const Users = {
  upsert(telegramId, username, firstName) {
    return db.prepare(`
      INSERT INTO users (telegram_id, username, first_name)
      VALUES (?, ?, ?)
      ON CONFLICT(telegram_id) DO UPDATE SET
        username = excluded.username,
        first_name = excluded.first_name
    `).run(telegramId, username, firstName)
  },

  getAll() {
    return db.prepare('SELECT * FROM users').all()
  },

  count() {
    return db.prepare('SELECT COUNT(*) as cnt FROM users').get().cnt
  }
}

// ==================== DEPLOYED BOT FUNCTIONS ====================
export const DeployedBots = {
  create(data) {
    return db.prepare(`
      INSERT INTO deployed_bots (
        owner_id, bot_token, bot_username, bot_id,
        response_limit, days, expired_at, has_ads, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')
    `).run(
      data.owner_id, data.bot_token, data.bot_username, data.bot_id,
      data.response_limit, data.days, data.expired_at, data.has_ads ? 1 : 0
    )
  },

  getByOwner(ownerId) {
    return db.prepare("SELECT * FROM deployed_bots WHERE owner_id = ? AND status != 'deleted' ORDER BY created_at DESC").all(ownerId)
  },

  getById(id) {
    return db.prepare('SELECT * FROM deployed_bots WHERE id = ?').get(id)
  },

  getByBotId(botId) {
    return db.prepare("SELECT * FROM deployed_bots WHERE bot_id = ? AND status = 'active'").get(botId)
  },

  update(id, fields) {
    const entries = Object.entries(fields)
    const set = entries.map(([k]) => `${k} = ?`).join(', ')
    const values = entries.map(([, v]) => v)
    return db.prepare(`UPDATE deployed_bots SET ${set} WHERE id = ?`).run(...values, id)
  },

  delete(id) {
    return db.prepare("UPDATE deployed_bots SET status = 'deleted' WHERE id = ?").run(id)
  },

  decrementResponse(id) {
    return db.prepare('UPDATE deployed_bots SET response_used = response_used + 1 WHERE id = ?').run(id)
  },

  countAll() {
    return db.prepare("SELECT COUNT(*) as cnt FROM deployed_bots WHERE status != 'deleted'").get().cnt
  },

  getAll(limit = 50, offset = 0) {
    return db.prepare("SELECT * FROM deployed_bots WHERE status != 'deleted' ORDER BY created_at DESC LIMIT ? OFFSET ?").all(limit, offset)
  },

  countActive() {
    return db.prepare("SELECT COUNT(*) as cnt FROM deployed_bots WHERE status = 'active'").get().cnt
  },

  // Bots yang mau expired (untuk notifikasi)
  getExpiringSoon(days) {
    const cutoff = new Date()
    cutoff.setDate(cutoff.getDate() + days)
    return db.prepare(`
      SELECT * FROM deployed_bots 
      WHERE status = 'active' 
        AND expired_at <= ? 
        AND expired_at > datetime('now')
    `).all(cutoff.toISOString())
  },

  // Bots yang limit hampir habis (>= 90% terpakai)
  getLowLimit() {
    return db.prepare(`
      SELECT * FROM deployed_bots 
      WHERE status = 'active'
        AND response_limit > 0
        AND CAST(response_used AS FLOAT) / response_limit >= 0.9
    `).all()
  },

  // Bots yang limit sudah 100% habis
  getEmptyLimit() {
    return db.prepare(`
      SELECT * FROM deployed_bots 
      WHERE status = 'active'
        AND response_limit > 0
        AND response_used >= response_limit
    `).all()
  }
}

// ==================== PRODUCTS FUNCTIONS ====================
export const Products = {
  create(data) {
    return db.prepare(`
      INSERT INTO products (bot_id, name, price, username, password, stock)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(data.bot_id, data.name, data.price, data.username, data.password, data.stock)
  },

  getByBot(botId) {
    return db.prepare("SELECT * FROM products WHERE bot_id = ? AND is_active = 1 ORDER BY id").all(botId)
  },

  getById(id) {
    return db.prepare('SELECT * FROM products WHERE id = ?').get(id)
  },

  update(id, fields) {
    const entries = Object.entries(fields)
    const set = entries.map(([k]) => `${k} = ?`).join(', ')
    const values = entries.map(([, v]) => v)
    return db.prepare(`UPDATE products SET ${set} WHERE id = ?`).run(...values, id)
  },

  decrementStock(id) {
    return db.prepare('UPDATE products SET stock = stock - 1, sold = sold + 1 WHERE id = ? AND stock > 0').run(id)
  },

  delete(id) {
    return db.prepare('UPDATE products SET is_active = 0 WHERE id = ?').run(id)
  }
}

// ==================== TRANSACTION FUNCTIONS ====================
export const Transactions = {
  create(data) {
    return db.prepare(`
      INSERT INTO product_transactions (bot_id, product_id, buyer_id, buyer_username, amount, payment_id, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(data.bot_id, data.product_id, data.buyer_id, data.buyer_username, data.amount, data.payment_id, data.status || 'pending')
  },

  update(id, fields) {
    const entries = Object.entries(fields)
    const set = entries.map(([k]) => `${k} = ?`).join(', ')
    const values = entries.map(([, v]) => v)
    return db.prepare(`UPDATE product_transactions SET ${set} WHERE id = ?`).run(...values, id)
  },

  getTodayRevenue(botId) {
    return db.prepare(`
      SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count
      FROM product_transactions 
      WHERE bot_id = ? AND status = 'paid' AND date(created_at) = date('now')
    `).get(botId)
  },

  getTotalRevenue(botId) {
    return db.prepare(`
      SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count
      FROM product_transactions WHERE bot_id = ? AND status = 'paid'
    `).get(botId)
  },

  getTopProducts(botId, limit = 3) {
    return db.prepare(`
      SELECT p.name, SUM(t.amount) as revenue, COUNT(t.id) as count
      FROM product_transactions t
      JOIN products p ON t.product_id = p.id
      WHERE t.bot_id = ? AND t.status = 'paid' AND date(t.created_at) = date('now')
      GROUP BY t.product_id
      ORDER BY count DESC LIMIT ?
    `).all(botId, limit)
  }
}

// ==================== OTP FUNCTIONS ====================
export const OtpOrders = {
  create(data) {
    return db.prepare(`
      INSERT INTO otp_orders (
        bot_id, buyer_id, buyer_username, order_id, number,
        country, service, operator, api_price, sell_price, profit, payment_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      data.bot_id, data.buyer_id, data.buyer_username, data.order_id, data.number,
      data.country, data.service, data.operator, data.api_price, data.sell_price,
      data.profit, data.payment_id, data.status || 'pending'
    )
  },

  update(id, fields) {
    const entries = Object.entries(fields)
    const set = entries.map(([k]) => `${k} = ?`).join(', ')
    const values = entries.map(([, v]) => v)
    return db.prepare(`UPDATE otp_orders SET ${set} WHERE id = ?`).run(...values, id)
  },

  getByOrderId(orderId) {
    return db.prepare('SELECT * FROM otp_orders WHERE order_id = ?').get(orderId)
  },

  getById(id) {
    return db.prepare('SELECT * FROM otp_orders WHERE id = ?').get(id)
  },

  getTodayStats(botId) {
    return db.prepare(`
      SELECT 
        COALESCE(SUM(sell_price), 0) as revenue,
        COALESCE(SUM(profit), 0) as total_profit,
        COUNT(*) as count
      FROM otp_orders WHERE bot_id = ? AND status = 'completed' AND date(created_at) = date('now')
    `).get(botId)
  },

  getTotalStats(botId) {
    return db.prepare(`
      SELECT COALESCE(SUM(profit), 0) as total_profit FROM otp_orders WHERE bot_id = ? AND status = 'completed'
    `).get(botId)
  }
}

// ==================== PENDING PAYMENTS ====================
export const PendingPayments = {
  create(data) {
    return db.prepare(`
      INSERT INTO pending_payments (
        type, user_id, chat_id, message_id, photo_message_id,
        data, payment_id, saweria_user_id, expires_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      data.type, data.user_id, data.chat_id, data.message_id, data.photo_message_id,
      JSON.stringify(data.data), data.payment_id, data.saweria_user_id, data.expires_at
    )
  },

  getByPaymentId(paymentId) {
    const row = db.prepare("SELECT * FROM pending_payments WHERE payment_id = ? AND status = 'pending'").get(paymentId)
    if (row) row.data = JSON.parse(row.data)
    return row
  },

  getPending() {
    return db.prepare("SELECT * FROM pending_payments WHERE status = 'pending'").all().map(r => {
      r.data = JSON.parse(r.data)
      return r
    })
  },

  update(id, fields) {
    const entries = Object.entries(fields)
    const set = entries.map(([k]) => `${k} = ?`).join(', ')
    const values = entries.map(([, v]) => v)
    return db.prepare(`UPDATE pending_payments SET ${set} WHERE id = ?`).run(...values, id)
  }
}

// ==================== USER STATES ====================
export const UserStates = {
  set(telegramId, state, data = null, botContext = null) {
    return db.prepare(`
      INSERT INTO user_states (telegram_id, bot_context, state, data, updated_at)
      VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(telegram_id) DO UPDATE SET
        bot_context = excluded.bot_context,
        state = excluded.state,
        data = excluded.data,
        updated_at = excluded.updated_at
    `).run(telegramId, botContext, state, data ? JSON.stringify(data) : null)
  },

  get(telegramId) {
    const row = db.prepare('SELECT * FROM user_states WHERE telegram_id = ?').get(telegramId)
    if (row && row.data) row.data = JSON.parse(row.data)
    return row
  },

  clear(telegramId) {
    return db.prepare('DELETE FROM user_states WHERE telegram_id = ?').run(telegramId)
  }
}

export default db
