// src/mainBot.js
import TelegramBot from 'node-telegram-bot-api'
import config from '../config.js'
import { Users, DeployedBots, UserStates, PendingPayments } from './database.js'
import { validateBotToken } from './telegram.js'
import { loginSaweria, createPayment, parseQrImage } from './saweria.js'
import { startPaymentCheck } from './paymentManager.js'
import {
  formatRupiah, formatDuration, maskToken, formatDate,
  generateInvoiceId, keyboard
} from './telegram.js'

// ==================== BOT INIT ====================
const bot = new TelegramBot(config.MAIN_BOT.TOKEN, { polling: true })

// ==================== HELPERS ====================
const isOperator = (userId) => config.OPERATORS.includes(String(userId))

function calcDeployPrice(response, days, noAds) {
  const responsePrice = (response / 1000) * config.PRICING.response_per_1k
  const daysPrice = days * config.PRICING.day_rate
  const adsPrice = noAds ? config.PRICING.no_ads_fee : 0
  return { responsePrice, daysPrice, adsPrice, total: responsePrice + daysPrice + adsPrice }
}

// ==================== /start ====================
bot.onText(/\/start/, async (msg) => {
  const { id: chatId, from } = msg
  Users.upsert(String(from.id), from.username, from.first_name)
  UserStates.clear(String(from.id))

  await bot.sendMessage(chatId,
    `🤖 <b>EclipxxDeployBot</b>

Selamat datang!
Deploy bot Telegram dengan mudah.`,
    {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [
        [{ text: '🚀 Deploy Bot', callback_data: 'deploy' }, { text: '📱 My Bots', callback_data: 'my_bots' }],
        [{ text: '📊 Status', callback_data: 'status' }, { text: 'ℹ️ Help', callback_data: 'help' }]
      ]}
    }
  )
})

// ==================== /deploy ====================
bot.onText(/\/deploy$/, async (msg) => {
  const chatId = msg.chat.id
  await showDeployInfo(chatId, msg.message_id)
})

async function showDeployInfo(chatId, messageId = null) {
  const text = `━━━『 <b>DEPLOY BOT</b> 』━━━

Format:
<code>/deploy &lt;token&gt; &lt;response&gt; &lt;hari&gt; &lt;iklan&gt;</code>

Contoh:
<code>/deploy 123456:ABC 10000 30 tidak</code>
(10rb response, 30 hari, tanpa iklan)

<code>/deploy 123456:ABC 5000 15 ya</code>
(5rb response, 15 hari, dengan iklan)

<b>Harga:</b>
• Response: ${formatRupiah(config.PRICING.response_per_1k)}/1.000
• Durasi: ${formatRupiah(config.PRICING.day_rate)}/hari
• Tanpa Iklan: +${formatRupiah(config.PRICING.no_ads_fee)}

Min: 1.000 response, 1 hari`

  const opts = {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'menu' }]] }
  }

  if (messageId) {
    await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts })
  } else {
    await bot.sendMessage(chatId, text, opts)
  }
}

// ==================== /deploy <args> ====================
bot.onText(/\/deploy (.+)/, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = String(msg.from.id)
  const args = match[1].trim().split(/\s+/)

  if (args.length < 4) {
    return bot.sendMessage(chatId, '❌ Format salah! Ketik /deploy untuk lihat format.', { parse_mode: 'HTML' })
  }

  const [token, responseStr, daysStr, adsStr] = args
  const response = parseInt(responseStr)
  const days = parseInt(daysStr)
  const noAds = adsStr.toLowerCase() === 'tidak'

  if (isNaN(response) || response < config.PRICING.min_response) {
    return bot.sendMessage(chatId, `❌ Response minimal ${config.PRICING.min_response.toLocaleString('id-ID')}`)
  }
  if (isNaN(days) || days < config.PRICING.min_days) {
    return bot.sendMessage(chatId, `❌ Minimal ${config.PRICING.min_days} hari`)
  }

  const validMsg = await bot.sendMessage(chatId, '🔍 Validating token...')

  // Simulate 2s delay for UX
  await new Promise(r => setTimeout(r, 2000))

  const validation = await validateBotToken(token)
  if (!validation.success) {
    return bot.editMessageText(`❌ Token tidak valid!\n\n${validation.message}`, {
      chat_id: chatId, message_id: validMsg.message_id
    })
  }

  const price = calcDeployPrice(response, days, noAds)

  const summaryText = `✅ Bot @${validation.bot_username} verified!

━━━『 <b>ORDER SUMMARY</b> 』━━━

Bot: @${validation.bot_username}
Response: ${response.toLocaleString('id-ID')}
Durasi: ${days} hari
Iklan: ${noAds ? 'Tanpa ✅' : 'Dengan Iklan'}

<b>Rincian:</b>
• Response: ${response.toLocaleString('id-ID')} = ${formatRupiah(price.responsePrice)}
• Durasi: ${days} hari = ${formatRupiah(price.daysPrice)}${noAds ? `\n• Tanpa Iklan = ${formatRupiah(price.adsPrice)}` : ''}

<b>TOTAL: ${formatRupiah(price.total)}</b>

Lanjut bayar?`

  // Store pending order in state
  UserStates.set(userId, 'deploy_confirm', {
    token, bot_id: String(validation.bot_id), bot_username: validation.bot_username,
    response, days, no_ads: noAds, price: price.total,
    summary_msg_id: validMsg.message_id
  })

  await bot.editMessageText(summaryText, {
    chat_id: chatId,
    message_id: validMsg.message_id,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: [
      [{ text: '✅ Ya, Bayar', callback_data: 'deploy_pay' }, { text: '❌ Batal', callback_data: 'deploy_cancel' }]
    ]}
  })
})

// ==================== /extend ====================
bot.onText(/\/extend (\d+) (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = String(msg.from.id)
  const stateData = UserStates.get(userId)

  if (!stateData || stateData.state !== 'extend_waiting') {
    return bot.sendMessage(chatId, '❌ Pilih bot dulu dari /start → My Bots → Extend')
  }

  const addResponse = parseInt(match[1])
  const addDays = parseInt(match[2])
  const botInfo = stateData.data

  const price = calcDeployPrice(addResponse, addDays, false) // no ads fee on extend

  const text = `━━━『 <b>ORDER SUMMARY</b> 』━━━

Bot: @${botInfo.bot_username}
Tambahan:
• +${addResponse.toLocaleString('id-ID')} response
• +${addDays} hari

<b>Rincian:</b>
• Response: ${addResponse.toLocaleString('id-ID')} = ${formatRupiah(price.responsePrice)}
• Durasi: ${addDays} hari = ${formatRupiah(price.daysPrice)}

<b>TOTAL: ${formatRupiah(price.total)}</b>

Lanjut bayar?`

  UserStates.set(userId, 'extend_confirm', {
    ...botInfo, add_response: addResponse, add_days: addDays, price: price.total
  })

  await bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: [
      [{ text: '✅ Ya, Bayar', callback_data: 'extend_pay' }, { text: '❌ Batal', callback_data: 'menu' }]
    ]}
  })
})

// ==================== /admin ====================
bot.onText(/\/admin/, async (msg) => {
  if (!isOperator(msg.from.id)) return

  const chatId = msg.chat.id
  await showAdminPanel(chatId)
})

async function showAdminPanel(chatId) {
  const totalBots = DeployedBots.countAll()
  const totalActive = DeployedBots.countActive()
  const totalUsers = Users.count()

  await bot.sendMessage(chatId,
    `━━━『 <b>ADMIN PANEL</b> 』━━━

📊 <b>STATISTIK:</b>
• Total Bots: ${totalBots}
• Active: ${totalActive}
• Users: ${totalUsers}

📅 <b>Hari Ini:</b>
• (Data transaksi hari ini)`,
    {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [
        [{ text: '📋 List Bots', callback_data: 'admin_list' }, { text: '🗑️ Delete', callback_data: 'admin_delete' }],
        [{ text: '📢 Broadcast', callback_data: 'admin_broadcast' }, { text: '💰 Revenue', callback_data: 'admin_revenue' }],
        [{ text: '🏠 Menu', callback_data: 'menu' }]
      ]}
    }
  )
}

// ==================== CALLBACK QUERY HANDLER ====================
bot.on('callback_query', async (query) => {
  const { id: queryId, from, message, data } = query
  const chatId = message.chat.id
  const userId = String(from.id)
  const msgId = message.message_id

  await bot.answerCallbackQuery(queryId)

  // ── MENU ──
  if (data === 'menu') {
    await bot.editMessageText(
      `🤖 <b>EclipxxDeployBot</b>\n\nSelamat datang!\nDeploy bot Telegram dengan mudah.`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '🚀 Deploy Bot', callback_data: 'deploy' }, { text: '📱 My Bots', callback_data: 'my_bots' }],
          [{ text: '📊 Status', callback_data: 'status' }, { text: 'ℹ️ Help', callback_data: 'help' }]
        ]}
      }
    )
    return
  }

  // ── DEPLOY ──
  if (data === 'deploy') {
    await bot.editMessageText(
      `━━━『 <b>DEPLOY BOT</b> 』━━━\n\nCara deploy:\nKetik /deploy\n\nFormat akan muncul di sana.`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'menu' }]] }
      }
    )
    return
  }

  // ── DEPLOY PAY ──
  if (data === 'deploy_pay') {
    const state = UserStates.get(userId)
    if (!state || state.state !== 'deploy_confirm') {
      return bot.sendMessage(chatId, '❌ Session expired. Mulai ulang.')
    }
    const orderData = state.data

    await bot.editMessageText('⏳ Membuat invoice...', {
      chat_id: chatId, message_id: msgId
    })

    await new Promise(r => setTimeout(r, 2000))

    // Login saweria
    const login = await loginSaweria(config.ADMIN_SAWERIA.email, config.ADMIN_SAWERIA.password)
    if (!login.success) {
      return bot.editMessageText(`❌ Error: ${login.message}`, { chat_id: chatId, message_id: msgId })
    }

    const invoiceId = generateInvoiceId()
    const pmsg = `Deploy bot @${orderData.bot_username} - ${invoiceId}`
    const payment = await createPayment(login.user_id, orderData.price, pmsg)

    if (!payment.success) {
      return bot.editMessageText(`❌ Error: ${payment.message}`, { chat_id: chatId, message_id: msgId })
    }

    const now = new Date()
    const expiredTime = new Date(now.getTime() + config.TIMEOUT.PAYMENT)
    const timeStr = expiredTime.toTimeString().slice(0, 5)

    const caption = `━━━『 <b>INVOICE</b> 』━━━

ID: <code>${invoiceId}</code>
Bot: @${orderData.bot_username}
Total: ${formatRupiah(orderData.price)}

Expired: 10 menit (${timeStr})

⏳ Cek otomatis tiap 5 detik...`

    // Delete old message, send QRIS photo
    await bot.deleteMessage(chatId, msgId)
    const qrBuffer = parseQrImage(payment.qr_image)
    const photoMsg = await bot.sendPhoto(chatId, qrBuffer, {
      caption, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'cancel_payment' }]] }
    })

    // Save pending payment
    const pending = PendingPayments.create({
      type: 'deploy',
      user_id: userId,
      chat_id: String(chatId),
      message_id: null,
      photo_message_id: String(photoMsg.message_id),
      data: {
        bot_token: orderData.token, bot_id: orderData.bot_id,
        bot_username: orderData.bot_username, response_limit: orderData.response,
        days: orderData.days, no_ads: orderData.no_ads,
        token_masked: maskToken(orderData.token),
        invoice_id: invoiceId
      },
      payment_id: payment.payment_id,
      saweria_user_id: login.user_id,
      expires_at: expiredTime.toISOString()
    })

    startPaymentCheck({ token: config.MAIN_BOT.TOKEN }, {
      ...pending, id: pending.lastInsertRowid,
      payment_id: payment.payment_id,
      saweria_user_id: login.user_id,
      expires_at: expiredTime.toISOString(),
      data: { /* will be fetched from DB */ }
    })

    UserStates.clear(userId)
    return
  }

  // ── DEPLOY CANCEL ──
  if (data === 'deploy_cancel') {
    UserStates.clear(userId)
    await bot.editMessageText(
      `❌ <b>ORDER DIBATALKAN</b>\n\nOrder telah dibatalkan.\n\nMau deploy lagi?`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '🚀 Deploy Bot', callback_data: 'deploy' }, { text: '🏠 Menu', callback_data: 'menu' }]
        ]}
      }
    )
    return
  }

  // ── MY BOTS ──
  if (data === 'my_bots') {
    const bots = DeployedBots.getByOwner(userId)

    if (!bots.length) {
      await bot.editMessageText(
        `━━━『 <b>MY BOTS</b> 』━━━\n\nBelum ada bot yang di-deploy.`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '🚀 Deploy Bot', callback_data: 'deploy' }],
            [{ text: '🏠 Menu', callback_data: 'menu' }]
          ]}
        }
      )
      return
    }

    let text = `━━━『 <b>MY BOTS</b> 』━━━\n\n`
    const botButtons = []

    bots.forEach((b, i) => {
      const remaining = b.response_limit - b.response_used
      const status = b.status === 'active' ? '✅ Aktif' : '❌ Nonaktif'
      const isLow = (b.response_used / b.response_limit) >= 0.9
      const statusIcon = isLow ? '⚠️ Limit Rendah' : status

      text += `${i + 1}. @${b.bot_username}\n`
      text += `   📊 ${b.response_used.toLocaleString()}/` +
              `${b.response_limit.toLocaleString()}\n`
      text += `   ⏰ ${formatDuration(b.expired_at)}\n`
      text += `   Status: ${statusIcon}\n\n`
      botButtons.push({ text: `⚙️ Bot ${i + 1}`, callback_data: `manage_bot_${b.id}` })
    })

    const rows = []
    for (let i = 0; i < botButtons.length; i += 2) {
      rows.push(botButtons.slice(i, i + 2))
    }
    rows.push([{ text: '🚀 Deploy Baru', callback_data: 'deploy' }])
    rows.push([{ text: '🏠 Menu', callback_data: 'menu' }])

    await bot.editMessageText(text, {
      chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: rows }
    })
    return
  }

  // ── MANAGE BOT ──
  if (data.startsWith('manage_bot_')) {
    const botId = parseInt(data.replace('manage_bot_', ''))
    const b = DeployedBots.getById(botId)
    if (!b || b.owner_id !== userId) return

    await bot.editMessageText(
      `━━━『 <b>KELOLA BOT</b> 』━━━

Bot: @${b.bot_username}
Token: <code>${maskToken(b.bot_token)}</code>
Response: ${b.response_used.toLocaleString()}/${b.response_limit.toLocaleString()}
Expired: ${formatDuration(b.expired_at)}
Status: ${b.status === 'active' ? '✅ Aktif' : '❌ Nonaktif'}

Link: t.me/${b.bot_username}`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '➕ Extend', callback_data: `extend_bot_${b.id}` }, { text: '🗑️ Delete', callback_data: `delete_bot_${b.id}` }],
          [{ text: '🔗 Open Bot', url: `https://t.me/${b.bot_username}` }],
          [{ text: '🔙 My Bots', callback_data: 'my_bots' }]
        ]}
      }
    )
    return
  }

  // ── EXTEND BOT ──
  if (data.startsWith('extend_bot_')) {
    const botId = parseInt(data.replace('extend_bot_', ''))
    const b = DeployedBots.getById(botId)
    if (!b) return

    UserStates.set(userId, 'extend_waiting', {
      bot_db_id: b.id, bot_username: b.bot_username, bot_id: b.bot_id
    })

    await bot.editMessageText(
      `━━━『 <b>EXTEND BOT</b> 』━━━

Bot: @${b.bot_username}
Limit: ${b.response_used.toLocaleString()}/${b.response_limit.toLocaleString()}
Expired: ${formatDuration(b.expired_at)}

Ketik format:
<code>/extend &lt;response&gt; &lt;hari&gt;</code>

Contoh:
<code>/extend 5000 15</code>

Harga sama kayak deploy.`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: `manage_bot_${b.id}` }]] }
      }
    )
    return
  }

  // ── DELETE BOT ──
  if (data.startsWith('delete_bot_')) {
    const botId = parseInt(data.replace('delete_bot_', ''))
    const b = DeployedBots.getById(botId)
    if (!b || b.owner_id !== userId) return

    await bot.editMessageText(
      `⚠️ <b>KONFIRMASI HAPUS</b>

Bot: @${b.bot_username}
Response: ${b.response_used.toLocaleString()}/${b.response_limit.toLocaleString()}

Yakin hapus bot ini?
Bot akan dinonaktifkan!`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '✅ Ya, Hapus', callback_data: `confirm_delete_${b.id}` }, { text: '❌ Batal', callback_data: `manage_bot_${b.id}` }]
        ]}
      }
    )
    return
  }

  if (data.startsWith('confirm_delete_')) {
    const botId = parseInt(data.replace('confirm_delete_', ''))
    const b = DeployedBots.getById(botId)
    if (!b || b.owner_id !== userId) return

    DeployedBots.delete(botId)

    await bot.editMessageText(
      `✅ <b>BOT DIHAPUS!</b>

Bot @${b.bot_username} sudah tidak aktif.
Data bot telah dihapus.`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '📱 My Bots', callback_data: 'my_bots' }, { text: '🏠 Menu', callback_data: 'menu' }]
        ]}
      }
    )
    return
  }

  // ── STATUS ──
  if (data === 'status') {
    const totalBots = DeployedBots.countAll()
    const active = DeployedBots.countActive()
    const users = Users.count()
    const now = new Date().toLocaleString('id-ID')

    await bot.editMessageText(
      `━━━『 <b>STATUS SISTEM</b> 』━━━

🤖 Total Bots: ${totalBots}
✅ Active: ${active}
❌ Inactive: ${totalBots - active}

👥 Total Users: ${users}

Status Server: ✅ Online
Last Update: ${now}`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '🔄 Refresh', callback_data: 'status' }, { text: '🏠 Menu', callback_data: 'menu' }]
        ]}
      }
    )
    return
  }

  // ── HELP ──
  if (data === 'help') {
    await bot.editMessageText(
      `ℹ️ <b>BANTUAN</b>

<b>Cara deploy bot:</b>
1. Buat bot di @BotFather
2. Copy token
3. Ketik /deploy lalu ikuti format

<b>Command:</b>
/start - Menu utama
/deploy - Deploy bot baru
/admin - Panel admin (operator)

<b>Support:</b>
@admin_eclipxx`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'menu' }]] }
      }
    )
    return
  }

  // ── ADMIN ──
  if (data === 'admin_list' && isOperator(from.id)) {
    const bots = DeployedBots.getAll(10, 0)
    let text = `━━━『 <b>ALL BOTS</b> 』━━━\n\n`

    bots.forEach((b, i) => {
      const used = (b.response_used / 1000).toFixed(1)
      const limit = (b.response_limit / 1000).toFixed(1)
      const status = b.status === 'active' ? '✅' : '❌'
      text += `${i + 1}. @${b.bot_username}\n   ${used}k/${limit}k | ${formatDuration(b.expired_at)} | ${status}\n\n`
    })

    await bot.editMessageText(text, {
      chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔙 Admin', callback_data: 'admin_back' }]] }
    })
    return
  }

  if (data === 'admin_broadcast' && isOperator(from.id)) {
    UserStates.set(userId, 'broadcast_waiting', null)
    await bot.editMessageText(
      `━━━『 <b>BROADCAST</b> 』━━━

Kirim pesan yang mau di-broadcast.

Total penerima: ${Users.count()} users

Ketik pesan sekarang.`,
      {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_back' }]] }
      }
    )
    return
  }
})

// ==================== BROADCAST HANDLER ====================
bot.on('message', async (msg) => {
  if (msg.text && msg.text.startsWith('/')) return

  const userId = String(msg.from.id)
  const chatId = msg.chat.id
  const state = UserStates.get(userId)
  if (!state) return

  if (state.state === 'broadcast_waiting' && isOperator(msg.from.id)) {
    const broadcastText = msg.text
    const users = Users.getAll()
    const total = users.length

    const statusMsg = await bot.sendMessage(chatId, `⏳ Sending broadcast...\n\nProgress: 0/${total}`)

    let sent = 0, failed = 0

    for (let i = 0; i < users.length; i++) {
      try {
        await bot.sendMessage(users[i].telegram_id, broadcastText, { parse_mode: 'HTML' })
        sent++
      } catch {
        failed++
      }

      if ((i + 1) % 10 === 0 || i === users.length - 1) {
        await bot.editMessageText(
          `⏳ Sending broadcast...\n\nProgress: ${i + 1}/${total}`,
          { chat_id: chatId, message_id: statusMsg.message_id }
        )
        await new Promise(r => setTimeout(r, 300))
      }
    }

    UserStates.clear(userId)
    await bot.editMessageText(
      `✅ <b>BROADCAST SUKSES!</b>\n\nTerkirim: ${sent}/${total}\nGagal: ${failed} (blocked bot)\n\nBroadcast selesai!`,
      {
        chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🔙 Admin', callback_data: 'admin_back' }]] }
      }
    )
  }
})

console.log('✅ Main bot started!')
export default bot
