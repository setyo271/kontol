// src/scheduler.js
/**
 * Cron-like scheduler untuk notifikasi:
 * - Bot hampir expired (3 hari & 1 hari sebelum)
 * - Limit hampir habis (< 10%)
 */

import { DeployedBots } from './database.js'
import { sendMessage, formatRupiah, formatDuration, keyboard } from './telegram.js'
import config from '../config.js'

// ==================== EXPIRY NOTIFICATIONS ====================
async function checkExpiryNotifications(mainBotToken) {
  const hour = new Date().getHours()
  if (hour !== config.NOTIFICATIONS.NOTIFY_HOUR) return

  for (const warningDays of config.NOTIFICATIONS.EXPIRE_WARNING_DAYS) {
    const bots = DeployedBots.getExpiringSoon(warningDays)

    for (const b of bots) {
      const remaining = b.response_limit - b.response_used
      const msg = `⚠️ <b>BOT AKAN EXPIRED!</b>

Bot: @${b.bot_username}
Sisa: ${warningDays} hari
Response: ${b.response_used.toLocaleString()}/${b.response_limit.toLocaleString()}

Extend sekarang agar bot tidak mati!`

      await sendMessage(mainBotToken, b.owner_id, msg, keyboard([
        [{ text: '➕ Extend Sekarang', callback_data: `extend_bot_${b.id}` }],
        [{ text: '⏰ Ingatkan Lagi', callback_data: 'my_bots' }]
      ]))
    }
  }
}

// ==================== LOW LIMIT NOTIFICATIONS ====================
async function checkLowLimitNotifications(mainBotToken) {
  const bots = DeployedBots.getLowLimit()

  for (const b of bots) {
    const remaining = b.response_limit - b.response_used
    const pct = ((b.response_used / b.response_limit) * 100).toFixed(1)

    const msg = `⚠️ <b>LIMIT HAMPIR HABIS!</b>

Bot: @${b.bot_username}
Response: ${b.response_used.toLocaleString()}/${b.response_limit.toLocaleString()} (${pct}%)
Expired: ${formatDuration(b.expired_at)}

Bot masih bisa berjalan tapi limit tinggal sedikit!

Tambah response sekarang?`

    await sendMessage(mainBotToken, b.owner_id, msg, keyboard([
      [{ text: '➕ Extend', callback_data: `extend_bot_${b.id}` }],
      [{ text: '📊 Lihat Detail', callback_data: `manage_bot_${b.id}` }]
    ]))
  }
}

// ==================== BOT LIMIT HABIS NOTIF ====================
async function checkEmptyLimitBots(mainBotToken) {
  // Get bots where used >= limit
  const { default: db } = await import('./database.js')
  const bots = db.prepare(`
    SELECT * FROM deployed_bots 
    WHERE status = 'active' AND response_used >= response_limit
  `).all()

  for (const b of bots) {
    const msg = `🚫 <b>LIMIT HABIS!</b>

Bot: @${b.bot_username}
Response: ${b.response_used.toLocaleString()}/${b.response_limit.toLocaleString()}
Expired: ${formatDuration(b.expired_at)}

Bot tidak bisa merespon user sampai limit ditambah!
Status: ⚠️ Tidak Merespon`

    await sendMessage(mainBotToken, b.owner_id, msg, keyboard([
      [{ text: '➕ Tambah Limit Sekarang', callback_data: `extend_bot_${b.id}` }]
    ]))
  }
}

// ==================== START SCHEDULER ====================
export function startScheduler(mainBotToken) {
  console.log('⏰ Scheduler started')

  // Check every hour
  setInterval(async () => {
    try {
      await checkExpiryNotifications(mainBotToken)
      await checkLowLimitNotifications(mainBotToken)
      await checkEmptyLimitBots(mainBotToken)
    } catch (e) {
      console.error('Scheduler error:', e.message)
    }
  }, 60 * 60 * 1000) // 1 hour

  // Run once on startup (after 5 seconds)
  setTimeout(async () => {
    try {
      await checkLowLimitNotifications(mainBotToken)
      await checkEmptyLimitBots(mainBotToken)
    } catch (e) {
      console.error('Initial scheduler error:', e.message)
    }
  }, 5000)
}
