// src/deployedBot.js
/**
 * Handler untuk BOT yang sudah di-deploy.
 * Setiap bot yang di-deploy akan dijalankan dengan token mereka sendiri,
 * tetapi menggunakan handler yang sama dari file ini.
 */

import TelegramBot from 'node-telegram-bot-api'
import { DeployedBots, Products, Transactions, OtpOrders, UserStates, PendingPayments } from './database.js'
import { loginSaweria, createPayment, parseQrImage } from './saweria.js'
import { checkBalance, getCountries, getServices, getOperators, orderNumber, COUNTRY_MAP, getServiceIcon, OPERATOR_LABELS } from './ditznesia.js'
import { startPaymentCheck } from './paymentManager.js'
import {
  formatRupiah, maskToken, formatDuration, formatDate,
  generateInvoiceId, parseWelcome
} from './telegram.js'
import config from '../config.js'

// ==================== START DEPLOYED BOT ====================
export function startDeployedBot(botRecord) {
  const bot = new TelegramBot(botRecord.bot_token, { polling: true })
  const botId = botRecord.bot_id
  const botToken = botRecord.bot_token

  // Helper: check if owner
  const isOwner = (userId) => String(userId) === botRecord.owner_id

  // Helper: check response limit
  async function checkLimit(chatId) {
    const current = DeployedBots.getByBotId(botId)
    if (!current || current.status !== 'active') return false
    if (current.response_used >= current.response_limit) return false
    if (new Date() > new Date(current.expired_at)) return false
    DeployedBots.decrementResponse(current.id)
    return true
  }

  // ==================== /start ====================
  bot.onText(/\/start/, async (msg) => {
    const { id: chatId, from } = msg
    const current = DeployedBots.getByBotId(botId)
    if (!current) return

    const hasLimit = await checkLimit(chatId)

    if (isOwner(from.id)) {
      // Owner panel
      const remaining = current.response_limit - current.response_used
      await bot.sendMessage(chatId,
        `━━━『 <b>OWNER PANEL</b> 』━━━

👋 Halo Owner!

📊 Stats:
• Response: ${remaining.toLocaleString()}/${current.response_limit.toLocaleString()}
• Expired: ${formatDuration(current.expired_at)}
• Status: ${current.status === 'active' ? '✅ Aktif' : '❌ Nonaktif'}`,
        {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '⚙️ Settings', callback_data: 'settings' }, { text: '💰 Saweria', callback_data: 'saweria' }],
            [{ text: '📦 Produk', callback_data: 'products_owner' }, { text: '📱 OTP', callback_data: 'otp_setup' }],
            [{ text: '📊 Rekap', callback_data: 'rekap' }, { text: 'ℹ️ Help', callback_data: 'help_owner' }]
          ]}
        }
      )
      return
    }

    // Regular user
    if (!hasLimit) {
      // Bot limit habis - tidak balas
      return
    }

    const welcome = parseWelcome(current.welcome_message || 'Halo {mention} {greeting}! Selamat datang!', from)
    const buttons = [
      [{ text: '🛒 Produk', callback_data: 'products' }, { text: '📱 OTP', callback_data: 'otp' }],
      [{ text: 'ℹ️ Info', callback_data: 'info' }]
    ]

    if (current.cover_file_id) {
      if (current.cover_type === 'video') {
        await bot.sendVideo(chatId, current.cover_file_id, {
          caption: welcome, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: buttons }
        })
      } else {
        await bot.sendPhoto(chatId, current.cover_file_id, {
          caption: welcome, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: buttons }
        })
      }
    } else {
      await bot.sendMessage(chatId, welcome, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
      })
    }
  })

  // ==================== /setmsg ====================
  bot.onText(/\/setmsg (.+)/, async (msg, match) => {
    if (!isOwner(msg.from.id)) return
    const newMsg = match[1]
    DeployedBots.update(botRecord.id, { welcome_message: newMsg })

    const preview = parseWelcome(newMsg, msg.from)
    await bot.sendMessage(msg.chat.id,
      `✅ <b>MESSAGE DISET!</b>

Preview:
${preview}

Akan tampil di /start user`,
      {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '⚙️ Settings', callback_data: 'settings' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
        ]}
      }
    )
  })

  // ==================== /setapikey ====================
  bot.onText(/\/setapikey (.+)/, async (msg, match) => {
    if (!isOwner(msg.from.id)) return
    const chatId = msg.chat.id
    const apiKey = match[1].trim()

    const validating = await bot.sendMessage(chatId, '🔍 Validating...')
    await new Promise(r => setTimeout(r, 2000))

    const balance = await checkBalance(apiKey)
    if (!balance.success) {
      return bot.editMessageText(`❌ API Key tidak valid!\n\n${balance.message}`, {
        chat_id: chatId, message_id: validating.message_id
      })
    }

    DeployedBots.update(botRecord.id, { api_key: apiKey })

    await bot.editMessageText(
      `✅ <b>API KEY DISIMPAN!</b>

Key: <code>${apiKey.slice(0, 8)}****${apiKey.slice(-4)}</code>

Saldo: ${formatRupiah(balance.balance)}
Status: ✅ Aktif

Fitur OTP aktif!`,
      {
        chat_id: chatId, message_id: validating.message_id, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '💰 Saldo', callback_data: 'otp_balance' }, { text: '💵 Markup', callback_data: 'otp_markup' }],
          [{ text: '📱 OTP', callback_data: 'otp_setup' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
        ]}
      }
    )
  })

  // ==================== /loginsaweria ====================
  bot.onText(/\/loginsaweria (\S+) (\S+)/, async (msg, match) => {
    if (!isOwner(msg.from.id)) return
    const chatId = msg.chat.id
    const [email, password] = [match[1], match[2]]

    const logMsg = await bot.sendMessage(chatId, '⏳ Login...')
    await new Promise(r => setTimeout(r, 2000))

    const login = await loginSaweria(email, password)
    if (!login.success) {
      return bot.editMessageText(`❌ Login gagal!\n\n${login.message}`, {
        chat_id: chatId, message_id: logMsg.message_id
      })
    }

    DeployedBots.update(botRecord.id, {
      saweria_user_id: login.user_id,
      saweria_email: email
    })

    await bot.editMessageText(
      `✅ <b>LOGIN SUKSES!</b>

Email: ${email}
User ID: ${login.user_id.slice(0, 8)}****

Pembayaran aktif! ✅`,
      {
        chat_id: chatId, message_id: logMsg.message_id, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '🚪 Logout', callback_data: 'saweria_logout' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
        ]}
      }
    )
  })

  // ==================== /markup ====================
  bot.onText(/\/markup (\d+)/, async (msg, match) => {
    if (!isOwner(msg.from.id)) return
    const markup = parseInt(match[1])
    DeployedBots.update(botRecord.id, { markup })

    const current = DeployedBots.getByBotId(botId)
    const exampleApi = 1500
    const exampleSell = exampleApi + markup

    await bot.sendMessage(msg.chat.id,
      `✅ <b>MARKUP DIUPDATE!</b>

Markup: ${formatRupiah(markup)}

Contoh:
• API: ${formatRupiah(exampleApi)}
• Markup: ${formatRupiah(markup)}
• Jual: ${formatRupiah(exampleSell)}
• Profit: ${formatRupiah(markup)}`,
      {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '📱 OTP', callback_data: 'otp_setup' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
        ]}
      }
    )
  })

  // ==================== /cekotp ====================
  bot.onText(/\/cekotp (.+)/, async (msg, match) => {
    const chatId = msg.chat.id
    const orderId = match[1].trim()
    const current = DeployedBots.getByBotId(botId)
    if (!current?.api_key) return bot.sendMessage(chatId, '❌ OTP tidak disetup')

    const checking = await bot.sendMessage(chatId, '🔍 Checking...')
    await new Promise(r => setTimeout(r, 1000))

    const { checkOTP } = await import('./ditznesia.js')
    const result = await checkOTP(current.api_key, orderId)

    if (result.received && result.otp) {
      await bot.editMessageText(
        `━━━『 <b>KODE OTP</b> 』━━━

✅ Order ID: <code>${orderId}</code>

Kode OTP:
<code>${result.otp}</code>

Langsung masukkan kode! 🚀`,
        { chat_id: chatId, message_id: checking.message_id, parse_mode: 'HTML' }
      )
    } else {
      await bot.editMessageText(
        `━━━『 <b>CEK OTP</b> 』━━━

Order ID: <code>${orderId}</code>
Status: OTP belum masuk...

Coba lagi dalam beberapa detik.`,
        { chat_id: chatId, message_id: checking.message_id, parse_mode: 'HTML' }
      )
    }
  })

  // ==================== PHOTO HANDLER (cover & product) ====================
  bot.on('photo', async (msg) => {
    if (!isOwner(msg.from.id)) return
    const chatId = msg.chat.id
    const userId = String(msg.from.id)
    const state = UserStates.get(userId)
    const fileId = msg.photo[msg.photo.length - 1].file_id

    if (state?.state === 'set_cover') {
      DeployedBots.update(botRecord.id, { cover_file_id: fileId, cover_type: 'photo' })
      UserStates.clear(userId)
      await bot.sendMessage(chatId,
        `✅ <b>COVER DISET!</b>\n\nCover akan tampil di /start user`,
        {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '⚙️ Settings', callback_data: 'settings' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
    } else if (state?.state === 'add_product_photo') {
      Products.update(state.data.product_id, { photo_file_id: fileId })
      UserStates.clear(userId)
      await bot.sendMessage(chatId,
        `✅ <b>FOTO DISIMPAN!</b>\n\nProduk aktif dan siap dijual!`,
        {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '📦 Produk', callback_data: 'products_owner' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
    }
  })

  // ==================== TEXT HANDLER (product input) ====================
  bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return
    const chatId = msg.chat.id
    const userId = String(msg.from.id)
    const state = UserStates.get(userId)
    if (!state) return

    // Add product text input
    if (state.state === 'add_product_waiting' && isOwner(msg.from.id)) {
      const parts = msg.text.split('|')
      if (parts.length < 5) {
        return bot.sendMessage(chatId, '❌ Format salah! Gunakan: nama|harga|user|pass|stok')
      }

      const [name, priceStr, username, password, stockStr] = parts
      const price = parseInt(priceStr)
      const stock = parseInt(stockStr)

      if (isNaN(price) || isNaN(stock)) {
        return bot.sendMessage(chatId, '❌ Harga dan stok harus angka!')
      }

      const result = Products.create({ bot_id: botId, name: name.trim(), price, username: username.trim(), password: password.trim(), stock })
      const productId = result.lastInsertRowid

      UserStates.set(userId, 'add_product_photo', { product_id: productId })

      await bot.sendMessage(chatId,
        `✅ <b>PRODUK DITAMBAH!</b>

ID: PROD_${productId}
Nama: ${name.trim()}
Harga: ${formatRupiah(price)}
Stock: ${stock}

Upload foto produk?
(Kirim foto atau Skip)`,
        {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '⏭️ Skip', callback_data: 'skip_product_photo' }],
            [{ text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
    }
  })

  // ==================== CALLBACK HANDLER ====================
  bot.on('callback_query', async (query) => {
    const { id: queryId, from, message, data } = query
    const chatId = message.chat.id
    const userId = String(from.id)
    const msgId = message.message_id
    const ownerMode = isOwner(from.id)

    await bot.answerCallbackQuery(queryId)

    const current = DeployedBots.getByBotId(botId)

    // ── MENU OWNER ──
    if (data === 'menu_owner' && ownerMode) {
      const remaining = current.response_limit - current.response_used
      await bot.editMessageText(
        `━━━『 <b>OWNER PANEL</b> 』━━━\n\n📊 Stats:\n• Response: ${remaining.toLocaleString()}/${current.response_limit.toLocaleString()}\n• Expired: ${formatDuration(current.expired_at)}\n• Status: ✅ Aktif`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '⚙️ Settings', callback_data: 'settings' }, { text: '💰 Saweria', callback_data: 'saweria' }],
            [{ text: '📦 Produk', callback_data: 'products_owner' }, { text: '📱 OTP', callback_data: 'otp_setup' }],
            [{ text: '📊 Rekap', callback_data: 'rekap' }, { text: 'ℹ️ Help', callback_data: 'help_owner' }]
          ]}
        }
      )
      return
    }

    // ── SETTINGS ──
    if (data === 'settings' && ownerMode) {
      await bot.editMessageText(
        `━━━『 <b>SETTINGS</b> 』━━━

Current:

📝 Message:
${current.welcome_message || 'Hello! 👋'}

📸 Cover: ${current.cover_file_id ? '✅ Sudah diset' : '❌ Belum diset'}

Response: ${(current.response_limit - current.response_used).toLocaleString()}/${current.response_limit.toLocaleString()}
Expired: ${formatDuration(current.expired_at)}`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '📝 Set Msg', callback_data: 'set_msg' }, { text: '📸 Set Cover', callback_data: 'set_cover' }],
            [{ text: '🔙 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
      return
    }

    // ── SET MESSAGE ──
    if (data === 'set_msg' && ownerMode) {
      await bot.editMessageText(
        `━━━『 <b>SET MESSAGE</b> 』━━━

Variables:
• {mention} - mention user
• {name} - nama depan
• {greeting} - salam otomatis

Example:
<code>Hi {mention} {greeting}! Welcome to my shop 🛒</code>

Ketik:
<code>/setmsg &lt;your_message&gt;</code>

Contoh:
<code>/setmsg Hi {mention}! Welcome 🛒</code>`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔙 Settings', callback_data: 'settings' }]] }
        }
      )
      return
    }

    // ── SET COVER ──
    if (data === 'set_cover' && ownerMode) {
      UserStates.set(userId, 'set_cover', null)
      await bot.editMessageText(
        `━━━『 <b>SET COVER</b> 』━━━

Kirim foto/video sekarang.

Max: 5 MB
Format: JPG/PNG/MP4

Atau ketik "cancel"`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '❌ Cancel', callback_data: 'settings' }]] }
        }
      )
      return
    }

    // ── SAWERIA ──
    if (data === 'saweria' && ownerMode) {
      await bot.editMessageText(
        `━━━『 <b>SAWERIA</b> 』━━━

Status: ${current.saweria_user_id ? '✅ Login' : '❌ Belum Login'}
${current.saweria_email ? `Email: ${current.saweria_email}` : ''}

Login untuk aktivasi pembayaran.

Ketik:
<code>/loginsaweria &lt;email&gt; &lt;password&gt;</code>

Contoh:
<code>/loginsaweria test@mail.com pass123</code>`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔙 Menu', callback_data: 'menu_owner' }]] }
        }
      )
      return
    }

    // ── PRODUCTS (OWNER) ──
    if (data === 'products_owner' && ownerMode) {
      const prods = Products.getByBot(botId)
      if (!prods.length) {
        await bot.editMessageText(
          `━━━『 <b>PRODUK</b> 』━━━\n\nBelum ada produk.\n\nTambah sekarang?`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [
              [{ text: '➕ Tambah', callback_data: 'add_product' }],
              [{ text: '🏠 Menu', callback_data: 'menu_owner' }]
            ]}
          }
        )
      } else {
        let text = `━━━『 <b>PRODUK</b> 』━━━\n\n`
        prods.forEach((p, i) => {
          text += `${i + 1}. 💎 ${p.name}\n   ${formatRupiah(p.price)} | Stok: ${p.stock}\n\n`
        })
        await bot.editMessageText(text, {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '➕ Tambah', callback_data: 'add_product' }],
            [{ text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        })
      }
      return
    }

    // ── ADD PRODUCT ──
    if (data === 'add_product' && ownerMode) {
      UserStates.set(userId, 'add_product_waiting', null)
      await bot.editMessageText(
        `━━━『 <b>TAMBAH PRODUK</b> 』━━━

Format:
<code>nama|harga|user|pass|stok</code>

Contoh:
<code>Diamond ML|15000|user123|pass456|10</code>

Kirim sekarang`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'products_owner' }]] }
        }
      )
      return
    }

    // ── SKIP PRODUCT PHOTO ──
    if (data === 'skip_product_photo' && ownerMode) {
      UserStates.clear(userId)
      await bot.editMessageText(
        `✅ Produk aktif dan siap dijual!`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '📦 Produk', callback_data: 'products_owner' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
      return
    }

    // ── OTP SETUP ──
    if (data === 'otp_setup' && ownerMode) {
      await bot.editMessageText(
        `━━━『 <b>OTP</b> 』━━━

Status: ${current.api_key ? '✅ Aktif' : '❌ Belum Setup'}
Markup: ${formatRupiah(current.markup || 0)}

Setup API Key:
1. Daftar: ditznesia.id/daftar
2. Login: ditznesia.id/login
3. Profil: ditznesia.id/profile
4. Copy API Key

Ketik:
<code>/setapikey &lt;api_key&gt;</code>`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '💰 Saldo', callback_data: 'otp_balance' }, { text: '💵 Markup', callback_data: 'otp_markup' }],
            [{ text: '🔗 Daftar', url: 'https://ditznesia.id/daftar' }, { text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
      return
    }

    // ── OTP BALANCE ──
    if (data === 'otp_balance' && ownerMode && current.api_key) {
      const balance = await checkBalance(current.api_key)
      await bot.answerCallbackQuery(queryId, {
        text: `Saldo: ${formatRupiah(balance.success ? balance.balance : 0)}`,
        show_alert: true
      })
      return
    }

    // ── OTP MARKUP ──
    if (data === 'otp_markup' && ownerMode) {
      await bot.editMessageText(
        `━━━『 <b>SET MARKUP</b> 』━━━

Markup saat ini: ${formatRupiah(current.markup || 0)}

Markup = profit per order OTP

Ketik:
<code>/markup &lt;jumlah&gt;</code>

Contoh:
<code>/markup 500</code>`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔙 OTP', callback_data: 'otp_setup' }]] }
        }
      )
      return
    }

    // ── REKAP ──
    if (data === 'rekap' && ownerMode) {
      await bot.editMessageText(
        `━━━『 <b>REKAP</b> 』━━━\n\nPilih:`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '📦 Produk', callback_data: 'rekap_produk' }, { text: '📱 OTP', callback_data: 'rekap_otp' }],
            [{ text: '💰 Total', callback_data: 'rekap_total' }],
            [{ text: '🏠 Menu', callback_data: 'menu_owner' }]
          ]}
        }
      )
      return
    }

    if (data === 'rekap_total' && ownerMode) {
      const today = Transactions.getTodayRevenue(botId)
      const otpToday = OtpOrders.getTodayStats(botId)
      const otpAll = OtpOrders.getTotalStats(botId)

      await bot.editMessageText(
        `━━━『 <b>REKAP TOTAL</b> 』━━━

📅 <b>Hari Ini:</b>
• Transaksi: ${today.count + otpToday.count}
• Revenue: ${formatRupiah(today.total + otpToday.revenue)}
  ├ Produk: ${formatRupiah(today.total)} (${today.count}x)
  └ OTP: ${formatRupiah(otpToday.revenue)} (${otpToday.count}x)
• Profit OTP: ${formatRupiah(otpToday.total_profit)}

💰 <b>Total Semua:</b>
• Profit OTP: ${formatRupiah(otpAll.total_profit)}`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '🔄 Refresh', callback_data: 'rekap_total' }, { text: '🔙 Menu', callback_data: 'rekap' }]
          ]}
        }
      )
      return
    }

    // ── PRODUCTS (USER) ──
    if (data === 'products') {
      const prods = Products.getByBot(botId)
      if (!prods.length) {
        await bot.editMessageText(
          `━━━『 <b>DAFTAR PRODUK</b> 』━━━\n\nBelum ada produk.`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🔙 Menu', callback_data: 'menu' }]] }
          }
        )
        return
      }

      let text = `━━━『 <b>DAFTAR PRODUK</b> 』━━━\n\n`
      const buttons = []

      prods.forEach((p, i) => {
        text += `${i + 1}. 💎 ${p.name}\n   ${formatRupiah(p.price)}\n   Stok: ${p.stock}\n\n`
        buttons.push({ text: `💎 ${p.name.slice(0, 20)}`, callback_data: `buy_${p.id}` })
      })

      const rows = []
      for (let i = 0; i < buttons.length; i += 2) rows.push(buttons.slice(i, i + 2))
      rows.push([{ text: '🔙 Menu', callback_data: 'menu' }])

      await bot.editMessageText(text, {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: rows }
      })
      return
    }

    // ── BUY PRODUCT ──
    if (data.startsWith('buy_')) {
      const productId = parseInt(data.replace('buy_', ''))
      const product = Products.getById(productId)
      if (!product) return

      if (product.stock <= 0) {
        await bot.editMessageText(
          `❌ <b>STOK HABIS!</b>\n\nProduk: ${product.name}\n\nStok saat ini: 0\n\nHubungi owner untuk restock.`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [
              [{ text: '🔙 Produk', callback_data: 'products' }, { text: '🏠 Menu', callback_data: 'menu' }]
            ]}
          }
        )
        return
      }

      if (product.photo_file_id) {
        await bot.deleteMessage(chatId, msgId)
        await bot.sendPhoto(chatId, product.photo_file_id, {
          caption: `━━━『 <b>DETAIL</b> 』━━━\n\n💎 ${product.name}\nHarga: ${formatRupiah(product.price)}\nStok: ${product.stock}\n\nBeli sekarang?`,
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '✅ Beli', callback_data: `confirm_buy_${productId}` }, { text: '❌ Batal', callback_data: 'products' }],
            [{ text: '🔙 Produk', callback_data: 'products' }]
          ]}
        })
      } else {
        await bot.editMessageText(
          `━━━『 <b>DETAIL</b> 』━━━\n\n💎 ${product.name}\nHarga: ${formatRupiah(product.price)}\nStok: ${product.stock}\n\nBeli sekarang?`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [
              [{ text: '✅ Beli', callback_data: `confirm_buy_${productId}` }, { text: '❌ Batal', callback_data: 'products' }]
            ]}
          }
        )
      }
      return
    }

    // ── CONFIRM BUY ──
    if (data.startsWith('confirm_buy_')) {
      if (!current.saweria_user_id) {
        return bot.sendMessage(chatId, '❌ Pembayaran belum disetup oleh owner.')
      }

      const productId = parseInt(data.replace('confirm_buy_', ''))
      const product = Products.getById(productId)
      if (!product || product.stock <= 0) {
        return bot.sendMessage(chatId, '❌ Stok habis!')
      }

      const processingMsg = await bot.sendMessage(chatId, '⏳ Membuat invoice...')
      await new Promise(r => setTimeout(r, 2000))

      const invoiceId = generateInvoiceId()
      const payment = await createPayment(
        current.saweria_user_id,
        product.price,
        `Beli ${product.name} - ${invoiceId}`
      )

      if (!payment.success) {
        return bot.editMessageText(`❌ Error: ${payment.message}`, {
          chat_id: chatId, message_id: processingMsg.message_id
        })
      }

      const expiredTime = new Date(Date.now() + config.TIMEOUT.PAYMENT)
      const timeStr = expiredTime.toTimeString().slice(0, 5)

      // Create transaction record
      const txResult = Transactions.create({
        bot_id: botId, product_id: productId,
        buyer_id: userId, buyer_username: from.username,
        amount: product.price, payment_id: payment.payment_id, status: 'pending'
      })

      await bot.deleteMessage(chatId, processingMsg.message_id)
      const qrBuffer = parseQrImage(payment.qr_image)
      const photoMsg = await bot.sendPhoto(chatId, qrBuffer, {
        caption: `━━━『 <b>INVOICE</b> 』━━━\n\nID: <code>${invoiceId}</code>\nProduk: ${product.name}\nHarga: ${formatRupiah(product.price)}\n\nExpired: 10 menit (${timeStr})\n\n⏳ Cek otomatis tiap 5 detik...`,
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'cancel_payment' }]] }
      })

      const pending = PendingPayments.create({
        type: 'product',
        user_id: userId, chat_id: String(chatId),
        message_id: null, photo_message_id: String(photoMsg.message_id),
        data: {
          bot_id: botId, bot_token: botToken,
          product_id: productId, transaction_id: txResult.lastInsertRowid,
          amount: product.price, buyer_username: from.username, invoice_id: invoiceId
        },
        payment_id: payment.payment_id,
        saweria_user_id: current.saweria_user_id,
        expires_at: expiredTime.toISOString()
      })

      startPaymentCheck({ token: botToken }, {
        id: pending.lastInsertRowid,
        payment_id: payment.payment_id,
        saweria_user_id: current.saweria_user_id,
        expires_at: expiredTime.toISOString(),
        data: {}
      })
      return
    }

    // ── OTP (USER) ──
    if (data === 'otp') {
      if (!current.api_key) {
        return bot.editMessageText(
          '❌ Layanan OTP belum tersedia.',
          { chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🔙 Menu', callback_data: 'menu' }]] } }
        )
      }

      const countryButtons = Object.entries(COUNTRY_MAP).map(([code, c]) => ({
        text: `${c.flag} ${c.name}`, callback_data: `otp_country_${code}`
      }))
      const rows = []
      for (let i = 0; i < countryButtons.length; i += 2) rows.push(countryButtons.slice(i, i + 2))
      rows.push([{ text: '🔙 Menu', callback_data: 'menu' }])

      await bot.editMessageText(
        `━━━『 <b>JASA OTP</b> 』━━━\n\nPilih negara:`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: rows } }
      )
      return
    }

    // ── OTP COUNTRY ──
    if (data.startsWith('otp_country_')) {
      const countryCode = data.replace('otp_country_', '')
      const country = COUNTRY_MAP[countryCode]
      if (!country) return

      await bot.editMessageText('⏳ Loading...', { chat_id: chatId, message_id: msgId })
      await new Promise(r => setTimeout(r, 1500))

      const servicesRes = await getServices(country.id)
      if (!servicesRes.success) {
        return bot.editMessageText('❌ Gagal load layanan.', { chat_id: chatId, message_id: msgId })
      }

      const serviceButtons = Object.entries(servicesRes.services).map(([code, s]) => ({
        text: `${getServiceIcon(s.layanan)} ${s.layanan}`,
        callback_data: `otp_svc_${countryCode}_${code}`
      }))

      const rows = []
      for (let i = 0; i < serviceButtons.length; i += 2) rows.push(serviceButtons.slice(i, i + 2))
      rows.push([{ text: '🔙 Negara', callback_data: 'otp' }])

      await bot.editMessageText(
        `━━━『 <b>LAYANAN</b> 』━━━\n\n${country.flag} ${country.name}\n\nPilih layanan:`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: rows } }
      )
      return
    }

    // ── OTP SERVICE (select operator) ──
    if (data.startsWith('otp_svc_')) {
      const [, , countryCode, serviceCode] = data.split('_')
      const country = COUNTRY_MAP[countryCode]

      await bot.editMessageText('⏳ Loading...', { chat_id: chatId, message_id: msgId })
      await new Promise(r => setTimeout(r, 1500))

      const servicesRes = await getServices(country.id)
      const serviceData = servicesRes.services?.[serviceCode]
      if (!serviceData) return

      const opsRes = await getOperators(country.id)
      const operators = opsRes.operators || ['any']

      const markup = current.markup || 0
      const totalPrice = serviceData.harga + markup

      const opButtons = operators.map(op => ({
        text: OPERATOR_LABELS[op] || op,
        callback_data: `otp_order_${countryCode}_${serviceCode}_${op}`
      }))

      const rows = []
      for (let i = 0; i < opButtons.length; i += 2) rows.push(opButtons.slice(i, i + 2))
      rows.push([{ text: '🔙 Layanan', callback_data: `otp_country_${countryCode}` }])

      await bot.editMessageText(
        `━━━『 <b>OPERATOR</b> 』━━━\n\n${country.flag} ${country.name} - ${serviceData.layanan}\n\nHarga API: ${formatRupiah(serviceData.harga)}\nMarkup: ${formatRupiah(markup)}\nTotal: ${formatRupiah(totalPrice)}\n\nPilih operator:`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: rows } }
      )
      return
    }

    // ── OTP ORDER ──
    if (data.startsWith('otp_order_')) {
      if (!current.api_key || !current.saweria_user_id) {
        return bot.sendMessage(chatId, '❌ OTP atau pembayaran belum disetup.')
      }

      const parts = data.split('_')
      // otp_order_ID_SVC_OP => parts: ['otp','order',countryCode,serviceCode,operator]
      const countryCode = parts[2]
      const serviceCode = parts[3]
      const operator = parts.slice(4).join('_')
      const country = COUNTRY_MAP[countryCode]

      await bot.editMessageText('⏳ Mencari nomor...\n\nTunggu sebentar...', {
        chat_id: chatId, message_id: msgId
      })
      await new Promise(r => setTimeout(r, 2500))

      const orderRes = await orderNumber(current.api_key, country.id, serviceCode, operator)

      if (!orderRes.success) {
        await bot.editMessageText(
          `❌ <b>NOMOR TIDAK ADA</b>\n\nStok habis saat ini.\n\nCoba:\n• Operator lain\n• Tunggu 5-10 menit\n• Layanan lain`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [
              [{ text: '🔄 Coba Lagi', callback_data: `otp_svc_${countryCode}_${serviceCode}` }],
              [{ text: '🔙 Operator', callback_data: `otp_svc_${countryCode}_${serviceCode}` }]
            ]}
          }
        )
        return
      }

      const markup = current.markup || 0
      const sellPrice = orderRes.price + markup
      const profit = markup

      // Save OTP order
      const otpResult = OtpOrders.create({
        bot_id: botId, buyer_id: userId, buyer_username: from.username,
        order_id: orderRes.order_id, number: orderRes.number,
        country: country.name, service: orderRes.service, operator: orderRes.operator,
        api_price: orderRes.price, sell_price: sellPrice, profit,
        payment_id: null, status: 'pending_confirm'
      })

      // 2-minute confirm timeout
      const confirmTimeout = setTimeout(async () => {
        OtpOrders.update(otpResult.lastInsertRowid, { status: 'cancelled' })
        const { cancelOrder } = await import('./ditznesia.js')
        await cancelOrder(current.api_key, orderRes.order_id)

        await bot.editMessageText(
          `⏰ <b>WAKTU HABIS!</b>\n\nOrder ID: <code>${orderRes.order_id}</code>\nNomor: <code>${orderRes.number}</code>\n\nOrder dibatalkan otomatis.\nNomor sudah di-release.\n\nMau coba lagi?`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [
              [{ text: '📱 Order OTP', callback_data: 'otp' }, { text: '🏠 Menu', callback_data: 'menu' }]
            ]}
          }
        )
      }, config.TIMEOUT.OTP_CONFIRM)

      await bot.editMessageText(
        `━━━『 <b>NOMOR DITEMUKAN</b> 』━━━

✅ Berhasil!

📱 Nomor: <tg-spoiler>${orderRes.number}</tg-spoiler>
🆔 ID: <code>${orderRes.order_id}</code>
🏷️ ${orderRes.service}
📡 ${orderRes.operator}

💰 Total: ${formatRupiah(sellPrice)}

⏰ Konfirmasi dalam 2 menit
atau nomor auto-cancel!

Lanjut bayar?`,
        {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: '✅ Bayar', callback_data: `otp_pay_${otpResult.lastInsertRowid}` }, { text: '❌ Batal', callback_data: 'otp' }]
          ]}
        }
      )

      // Store timeout ref (simple approach)
      UserStates.set(userId, 'otp_confirm', {
        otp_db_id: otpResult.lastInsertRowid,
        order_id: orderRes.order_id,
        timeout_ref: Date.now() + config.TIMEOUT.OTP_CONFIRM
      })
      return
    }

    // ── OTP PAY ──
    if (data.startsWith('otp_pay_')) {
      const otpDbId = parseInt(data.replace('otp_pay_', ''))
      const otpOrder = OtpOrders.getByOrderId // We'll fetch by db id differently
      // Fetch from DB using order internal id
      const allPending = PendingPayments.getPending()

      // Get otp order details from OtpOrders - we need to find by id
      const { default: db } = await import('./database.js')
      const otpRec = db.prepare('SELECT * FROM otp_orders WHERE id = ?').get(otpDbId)
      if (!otpRec || !current.saweria_user_id) return

      await bot.editMessageText('⏳ Membuat invoice...', { chat_id: chatId, message_id: msgId })
      await new Promise(r => setTimeout(r, 2500))

      const invoiceId = generateInvoiceId()
      const payment = await createPayment(
        current.saweria_user_id,
        otpRec.sell_price,
        `OTP ${otpRec.service} - ${invoiceId}`
      )

      if (!payment.success) {
        return bot.editMessageText(`❌ Error: ${payment.message}`, {
          chat_id: chatId, message_id: msgId
        })
      }

      OtpOrders.update(otpDbId, { payment_id: payment.payment_id, status: 'pending_payment' })

      const expiredTime = new Date(Date.now() + config.TIMEOUT.PAYMENT)
      const timeStr = expiredTime.toTimeString().slice(0, 5)

      await bot.deleteMessage(chatId, msgId)
      const qrBuffer = parseQrImage(payment.qr_image)
      const photoMsg = await bot.sendPhoto(chatId, qrBuffer, {
        caption: `━━━『 <b>INVOICE OTP</b> 』━━━\n\nID: <code>${invoiceId}</code>\nOrder ID: <code>${otpRec.order_id}</code>\nLayanan: ${otpRec.service}\nNomor: <tg-spoiler>${otpRec.number}</tg-spoiler>\n\nTotal: ${formatRupiah(otpRec.sell_price)}\nExpired: 10 menit (${timeStr})\n\n⏳ Cek otomatis tiap 5 detik...`,
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'cancel_payment' }]] }
      })

      const pending = PendingPayments.create({
        type: 'otp',
        user_id: userId, chat_id: String(chatId),
        message_id: null, photo_message_id: String(photoMsg.message_id),
        data: {
          bot_id: botId, bot_token: botToken,
          otp_order_id: otpDbId, order_id: otpRec.order_id,
          number: otpRec.number, service: otpRec.service,
          api_price: otpRec.api_price, sell_price: otpRec.sell_price,
          profit: otpRec.profit, api_key: current.api_key,
          country_flag: Object.values(COUNTRY_MAP).find(c => c.name.toLowerCase() === otpRec.country.toLowerCase())?.flag || '🌍',
          invoice_id: invoiceId, owner_username: 'OwnerUsername',
          buyer_id: userId, buyer_username: from.username
        },
        payment_id: payment.payment_id,
        saweria_user_id: current.saweria_user_id,
        expires_at: expiredTime.toISOString()
      })

      startPaymentCheck({ token: botToken }, {
        id: pending.lastInsertRowid,
        payment_id: payment.payment_id,
        saweria_user_id: current.saweria_user_id,
        expires_at: expiredTime.toISOString(),
        data: {}
      })

      UserStates.clear(userId)
      return
    }

    // ── MENU (USER) ──
    if (data === 'menu') {
      // Try to go back to start message
      const welcome = parseWelcome(current.welcome_message || 'Halo {mention} {greeting}! Selamat datang!', from)
      await bot.editMessageText(welcome, {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '🛒 Produk', callback_data: 'products' }, { text: '📱 OTP', callback_data: 'otp' }],
          [{ text: 'ℹ️ Info', callback_data: 'info' }]
        ]}
      })
      return
    }
  })

  console.log(`✅ Deployed bot @${botRecord.bot_username} started!`)
  return bot
}
