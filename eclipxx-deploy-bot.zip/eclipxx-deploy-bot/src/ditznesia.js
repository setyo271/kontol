// src/ditznesia.js
import axios from 'axios'
import config from '../config.js'

const BASE = config.API.DITZNESIA

// ==================== CHECK BALANCE ====================
export async function checkBalance(apiKey) {
  try {
    const res = await axios.get(`${BASE}/balance.php`, { params: { api_key: apiKey } })
    if (res.data.success) return { success: true, balance: res.data.data.saldo }
    return { success: false, message: 'Gagal cek saldo' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== GET COUNTRIES ====================
export async function getCountries() {
  try {
    const res = await axios.get(`${BASE}/negara.php`)
    if (res.data.success) return { success: true, countries: res.data.data }
    return { success: false, message: 'Gagal ambil negara' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== GET OPERATORS ====================
export async function getOperators(countryId) {
  try {
    const res = await axios.get(`${BASE}/operator.php`, { params: { negara: countryId } })
    if (res.data.success) return { success: true, operators: res.data.data[countryId] || [] }
    return { success: false, message: 'Gagal ambil operator' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== GET SERVICES ====================
export async function getServices(countryId) {
  try {
    const res = await axios.get(`${BASE}/layanan.php`, { params: { negara: countryId } })
    if (res.data[countryId]) return { success: true, services: res.data[countryId] }
    return { success: false, message: 'Negara tidak ditemukan' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== ORDER NUMBER ====================
export async function orderNumber(apiKey, countryId, serviceCode, operator) {
  try {
    const res = await axios.get(`${BASE}/order.php`, {
      params: { api_key: apiKey, negara: countryId, layanan: serviceCode, operator }
    })
    if (res.data.success) {
      return {
        success: true,
        order_id: res.data.data.order_id,
        number: res.data.data.number,
        country: res.data.data.negara,
        service: res.data.data.layanan,
        operator: res.data.data.operator,
        price: res.data.data.harga
      }
    }
    return { success: false, message: res.data.message || 'Nomor tidak tersedia' }
  } catch (e) {
    return { success: false, message: e.response?.data?.message || e.message }
  }
}

// ==================== CHECK OTP ====================
export async function checkOTP(apiKey, orderId) {
  try {
    const res = await axios.get(`${BASE}/sms.php`, { params: { api_key: apiKey, id: orderId } })
    if (res.data.success) {
      return {
        success: true,
        order_id: res.data.data.order_id,
        otp: res.data.data.otp || null,
        received: res.data.data.otp !== null
      }
    }
    return { success: false, message: res.data.message || 'Gagal cek OTP' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== CANCEL ORDER ====================
export async function cancelOrder(apiKey, orderId) {
  try {
    const res = await axios.get(`${BASE}/cancel.php`, { params: { api_key: apiKey, id: orderId } })
    if (res.data.success) {
      return {
        success: true,
        order_id: res.data.data.order_id,
        refunded: res.data.data.refunded_amount || 0,
        message: res.data.data.message
      }
    }
    return { success: false, message: res.data.message || 'Gagal cancel' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== COUNTRY MAP ====================
export const COUNTRY_MAP = {
  'ID': { id: '6',  flag: '🇮🇩', name: 'Indonesia' },
  'MY': { id: '60', flag: '🇲🇾', name: 'Malaysia' },
  'US': { id: '1',  flag: '🇺🇸', name: 'USA' },
  'TH': { id: '66', flag: '🇹🇭', name: 'Thailand' },
  'VN': { id: '84', flag: '🇻🇳', name: 'Vietnam' },
  'PH': { id: '63', flag: '🇵🇭', name: 'Philippines' },
}

// ==================== SERVICE ICONS ====================
export const SERVICE_ICONS = {
  'instagram': '📷',
  'whatsapp': '💬',
  'facebook': '👥',
  'twitter': '🐦',
  'gmail': '📧',
  'telegram': '🎮',
}

export function getServiceIcon(service) {
  return SERVICE_ICONS[service.toLowerCase()] || '📱'
}

// ==================== OPERATOR MAP ====================
export const OPERATOR_LABELS = {
  'any': '🎲 Random',
  'telkomsel': '📶 Telkomsel',
  'indosat': '📶 Indosat',
  'xl': '📶 XL',
  'tri': '📶 Tri',
  'axis': '📶 Axis',
}
