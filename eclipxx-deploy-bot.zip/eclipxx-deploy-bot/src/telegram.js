// src/telegram.js
import axios from 'axios'
import config from '../config.js'

const BASE = config.API.TELEGRAM

// ==================== VALIDATE BOT TOKEN ====================
export async function validateBotToken(token) {
  try {
    const res = await axios.get(`${BASE}/bot${token}/getMe`)
    if (res.data.ok) {
      return {
        success: true,
        bot_id: res.data.result.id,
        bot_name: res.data.result.first_name,
        bot_username: res.data.result.username,
        is_bot: res.data.result.is_bot
      }
    }
    return { success: false, message: 'Token tidak valid' }
  } catch (e) {
    return { success: false, message: e.response?.data?.description || 'Token tidak valid' }
  }
}

// ==================== SET WEBHOOK ====================
export async function setWebhook(token, webhookUrl) {
  try {
    const res = await axios.post(`${BASE}/bot${token}/setWebhook`, {
      url: webhookUrl,
      allowed_updates: ['message', 'callback_query']
    })
    return res.data.ok
      ? { success: true, message: 'Webhook set' }
      : { success: false, message: 'Gagal set webhook' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== DELETE WEBHOOK ====================
export async function deleteWebhook(token) {
  try {
    const res = await axios.get(`${BASE}/bot${token}/deleteWebhook`)
    return res.data.ok
      ? { success: true }
      : { success: false, message: 'Gagal delete webhook' }
  } catch (e) {
    return { success: false, message: e.message }
  }
}

// ==================== SEND MESSAGE ====================
export async function sendMessage(token, chatId, text, extra = {}) {
  try {
    const res = await axios.post(`${BASE}/bot${token}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      ...extra
    })
    return res.data
  } catch (e) {
    console.error('sendMessage error:', e.response?.data || e.message)
    return null
  }
}

// ==================== EDIT MESSAGE ====================
export async function editMessage(token, chatId, messageId, text, extra = {}) {
  try {
    const res = await axios.post(`${BASE}/bot${token}/editMessageText`, {
      chat_id: chatId,
      message_id: messageId,
      text,
      parse_mode: 'HTML',
      ...extra
    })
    return res.data
  } catch (e) {
    return null
  }
}

// ==================== DELETE MESSAGE ====================
export async function deleteMessage(token, chatId, messageId) {
  try {
    await axios.post(`${BASE}/bot${token}/deleteMessage`, {
      chat_id: chatId,
      message_id: messageId
    })
    return true
  } catch (e) {
    return false
  }
}

// ==================== SEND PHOTO ====================
export async function sendPhoto(token, chatId, photo, caption = '', extra = {}) {
  try {
    const isBuffer = Buffer.isBuffer(photo)
    let body

    if (isBuffer) {
      const FormData = (await import('form-data')).default
      const form = new FormData()
      form.append('chat_id', chatId)
      form.append('photo', photo, { filename: 'qris.png', contentType: 'image/png' })
      form.append('caption', caption)
      form.append('parse_mode', 'HTML')
      if (extra.reply_markup) form.append('reply_markup', JSON.stringify(extra.reply_markup))

      const res = await axios.post(`${BASE}/bot${token}/sendPhoto`, form, {
        headers: form.getHeaders()
      })
      return res.data
    } else {
      const res = await axios.post(`${BASE}/bot${token}/sendPhoto`, {
        chat_id: chatId,
        photo,
        caption,
        parse_mode: 'HTML',
        ...extra
      })
      return res.data
    }
  } catch (e) {
    console.error('sendPhoto error:', e.response?.data || e.message)
    return null
  }
}

// ==================== EDIT MESSAGE CAPTION ====================
export async function editCaption(token, chatId, messageId, caption, extra = {}) {
  try {
    const res = await axios.post(`${BASE}/bot${token}/editMessageCaption`, {
      chat_id: chatId,
      message_id: messageId,
      caption,
      parse_mode: 'HTML',
      ...extra
    })
    return res.data
  } catch (e) {
    return null
  }
}

// ==================== EDIT MESSAGE MEDIA ====================
export async function editMedia(token, chatId, messageId, mediaFileId, caption = '') {
  try {
    const res = await axios.post(`${BASE}/bot${token}/editMessageMedia`, {
      chat_id: chatId,
      message_id: messageId,
      media: { type: 'photo', media: mediaFileId, caption, parse_mode: 'HTML' }
    })
    return res.data
  } catch (e) {
    return null
  }
}

// ==================== ANSWER CALLBACK ====================
export async function answerCallback(token, callbackQueryId, text = '') {
  try {
    await axios.post(`${BASE}/bot${token}/answerCallbackQuery`, {
      callback_query_id: callbackQueryId,
      text
    })
  } catch (e) { /* ignore */ }
}

// ==================== HELPER: FORMAT CURRENCY ====================
export function formatRupiah(amount) {
  return `Rp ${Number(amount).toLocaleString('id-ID')}`
}

// ==================== HELPER: INLINE KEYBOARD ====================
export function keyboard(buttons) {
  return { reply_markup: { inline_keyboard: buttons } }
}

// ==================== HELPER: GREETING ====================
export function getGreeting() {
  const hour = new Date().getHours()
  if (hour >= 5 && hour < 12) return 'Good Morning'
  if (hour >= 12 && hour < 15) return 'Good Afternoon'
  if (hour >= 15 && hour < 19) return 'Good Evening'
  return 'Good Night'
}

// ==================== HELPER: REPLACE VARIABLES ====================
export function parseWelcome(template, user) {
  const mention = user.username ? `@${user.username}` : user.first_name
  return template
    .replace(/{mention}/g, mention)
    .replace(/{name}/g, user.first_name || 'User')
    .replace(/{greeting}/g, getGreeting())
}

// ==================== HELPER: MASK TOKEN ====================
export function maskToken(token) {
  if (!token) return '****'
  const parts = token.split(':')
  const id = parts[0]
  const secret = parts[1] || ''
  return `${id}:${secret.slice(0, 4)}****`
}

// ==================== HELPER: FORMAT DATE ====================
export function formatDate(dateStr) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
}

// ==================== HELPER: FORMAT DURATION ====================
export function formatDuration(expiredAt) {
  const now = new Date()
  const end = new Date(expiredAt)
  const diff = end - now

  if (diff <= 0) return 'Expired'

  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

  return `${days}D ${hours}H`
}

// ==================== HELPER: GENERATE INVOICE ID ====================
export function generateInvoiceId() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let id = ''
  for (let i = 0; i < 8; i++) id += chars[Math.floor(Math.random() * chars.length)]
  return id
}
