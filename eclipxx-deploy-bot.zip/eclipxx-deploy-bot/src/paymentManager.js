// src/paymentManager.js
import { PendingPayments, DeployedBots, Products, Transactions, OtpOrders } from './database.js'
import { checkPayment, parseQrImage } from './saweria.js'
import { checkOTP, cancelOrder } from './ditznesia.js'
import {
  sendMessage, deleteMessage, editCaption,
  formatRupiah, formatDate, formatDuration, keyboard
} from './telegram.js'
import config from '../config.js'

const activeChecks = new Map() // paymentId -> intervalId

// ==================== START CHECKING A PAYMENT ====================
export function startPaymentCheck(mainBot, payment) {
  if (activeChecks.has(payment.payment_id)) return

  const intervalId = setInterval(async () => {
    try {
      // Check if expired
      if (new Date() > new Date(payment.expires_at)) {
        await handlePaymentTimeout(mainBot, payment)
        stopCheck(payment.payment_id)
        return
      }

      // Re-fetch from DB to make sure still pending
      const current = PendingPayments.getByPaymentId(payment.payment_id)
      if (!current || current.status !== 'pending') {
        stopCheck(payment.payment_id)
        return
      }

      // Check payment
      const result = await checkPayment(current.saweria_user_id, current.payment_id)
      if (result.paid) {
        stopCheck(payment.payment_id)
        await handlePaymentSuccess(mainBot, current)
      }
    } catch (e) {
      console.error('Payment check error:', e.message)
    }
  }, config.TIMEOUT.CHECK_INTERVAL)

  activeChecks.set(payment.payment_id, intervalId)

  // Auto stop at timeout
  setTimeout(() => stopCheck(payment.payment_id), config.TIMEOUT.PAYMENT + 5000)
}

function stopCheck(paymentId) {
  if (activeChecks.has(paymentId)) {
    clearInterval(activeChecks.get(paymentId))
    activeChecks.delete(paymentId)
  }
}

// ==================== PAYMENT SUCCESS HANDLER ====================
async function handlePaymentSuccess(mainBot, payment) {
  PendingPayments.update(payment.id, { status: 'paid' })

  const { type, data, chat_id, photo_message_id, user_id } = payment

  // Delete QRIS photo
  if (photo_message_id) {
    await deleteMessage(mainBot.token, chat_id, photo_message_id)
  }

  if (type === 'deploy') {
    await handleDeploySuccess(mainBot, data, chat_id, user_id)
  } else if (type === 'extend') {
    await handleExtendSuccess(mainBot, data, chat_id)
  } else if (type === 'product') {
    await handleProductSuccess(mainBot, data, chat_id, user_id)
  } else if (type === 'otp') {
    await handleOtpPaymentSuccess(mainBot, data, chat_id)
  }
}

// ==================== DEPLOY SUCCESS ====================
async function handleDeploySuccess(mainBot, data, chatId, userId) {
  const expiredAt = new Date()
  expiredAt.setDate(expiredAt.getDate() + data.days)

  DeployedBots.create({
    owner_id: userId,
    bot_token: data.bot_token,
    bot_username: data.bot_username,
    bot_id: data.bot_id,
    response_limit: data.response_limit,
    days: data.days,
    expired_at: expiredAt.toISOString(),
    has_ads: !data.no_ads
  })

  const msg = `✅ <b>PEMBAYARAN SUKSES!</b>

Bot: @${data.bot_username}
Token: <code>${data.token_masked}</code>
Response: ${Number(data.response_limit).toLocaleString('id-ID')}
Expired: ${data.days} hari (${formatDate(expiredAt)})
Ads: ${data.no_ads ? 'Tanpa ✅' : 'Dengan Iklan'}

🎉 Bot sudah aktif!
Link: t.me/${data.bot_username}`

  await sendMessage(mainBot.token, chatId, msg, keyboard([
    [{ text: '📱 Kelola Bot', callback_data: 'my_bots' }, { text: '🚀 Deploy Lagi', callback_data: 'deploy' }],
    [{ text: '🏠 Menu Utama', callback_data: 'menu' }]
  ]))
}

// ==================== EXTEND SUCCESS ====================
async function handleExtendSuccess(mainBot, data, chatId) {
  const bot = DeployedBots.getById(data.bot_db_id)
  if (!bot) return

  const newExpired = new Date(bot.expired_at)
  newExpired.setDate(newExpired.getDate() + data.days)

  DeployedBots.update(data.bot_db_id, {
    response_limit: bot.response_limit + data.response,
    days: bot.days + data.days,
    expired_at: newExpired.toISOString()
  })

  const msg = `✅ <b>EXTEND SUKSES!</b>

Bot: @${bot.bot_username}
+Response: ${Number(data.response).toLocaleString('id-ID')}
+Durasi: ${data.days} hari
Expired baru: ${formatDate(newExpired)}`

  await sendMessage(mainBot.token, chatId, msg, keyboard([
    [{ text: '📱 My Bots', callback_data: 'my_bots' }, { text: '🏠 Menu', callback_data: 'menu' }]
  ]))
}

// ==================== PRODUCT SUCCESS ====================
async function handleProductSuccess(mainBot, data, chatId, userId) {
  const product = Products.getById(data.product_id)
  if (!product) return

  // Decrement stock
  Products.decrementStock(data.product_id)

  // Update transaction
  Transactions.update(data.transaction_id, { status: 'paid' })

  const msg = `✅ <b>PEMBELIAN SUKSES!</b>

Produk: ${product.name}

━━━『 DATA LOGIN 』━━━
Username: <code>${product.username}</code>
Password: <code>${product.password}</code>

Terima kasih sudah belanja! 🎉`

  await sendMessage(data.bot_token, chatId, msg, keyboard([
    [{ text: '🛒 Belanja Lagi', callback_data: 'products' }, { text: '🏠 Menu', callback_data: 'menu' }]
  ]))

  // Notify owner
  const deployedBot = DeployedBots.getByBotId(data.bot_id)
  if (deployedBot) {
    const todayRevenue = Transactions.getTodayRevenue(data.bot_id)
    const ownerMsg = `🔔 <b>PEMBELIAN BARU!</b>

Produk: ${product.name}
Harga: ${formatRupiah(data.amount)}
Pembeli: ${data.buyer_username ? `@${data.buyer_username}` : userId}
Waktu: ${new Date().toLocaleString('id-ID')}

Total penjualan hari ini: ${formatRupiah(todayRevenue.total)}`

    await sendMessage(data.bot_token, deployedBot.owner_id, ownerMsg, keyboard([
      [{ text: '📊 Rekap', callback_data: 'rekap' }]
    ]))
  }
}

// ==================== OTP PAYMENT SUCCESS ====================
async function handleOtpPaymentSuccess(mainBot, data, chatId) {
  // Update order status to paid
  OtpOrders.update(data.otp_order_id, { status: 'paid' })

  const phoneHidden = `||${data.number}||`

  await sendMessage(data.bot_token, chatId,
    `✅ <b>PEMBAYARAN SUKSES!</b>

📱 Nomor: <tg-spoiler>${data.number}</tg-spoiler>
🆔 ID: <code>${data.order_id}</code>
🏷️ ${data.service}

Nomor aktif! Menunggu OTP...
Cek: /cekotp ${data.order_id}

⏳ Auto-check tiap 5 detik...`,
    keyboard([[{ text: '🔄 Cek OTP', callback_data: `check_otp_${data.order_id}` }]])
  )

  // Start OTP polling
  startOtpPolling(data, chatId)
}

// ==================== OTP POLLING ====================
const otpPolls = new Map()

function startOtpPolling(data, chatId) {
  if (otpPolls.has(data.order_id)) return

  const timeout = setTimeout(async () => {
    // OTP timeout
    stopOtpPoll(data.order_id)
    await cancelOrder(data.api_key, data.order_id)
    OtpOrders.update(data.otp_order_id, { status: 'timeout' })

    await sendMessage(data.bot_token, chatId,
      `⏰ <b>OTP TIMEOUT!</b>

Order ID: <code>${data.order_id}</code>
Nomor: <code>${data.number}</code>

OTP tidak masuk dalam 10 menit.
Status: Dibatalkan otomatis

Untuk refund, hubungi owner:
@${data.owner_username}
Invoice ID: <code>${data.invoice_id}</code>`,
      keyboard([[{ text: '🏠 Menu', callback_data: 'menu' }]])
    )
  }, config.TIMEOUT.OTP_WAIT)

  const intervalId = setInterval(async () => {
    try {
      const result = await checkOTP(data.api_key, data.order_id)
      if (result.received && result.otp) {
        stopOtpPoll(data.order_id)
        clearTimeout(timeout)

        OtpOrders.update(data.otp_order_id, { otp_code: result.otp, status: 'completed' })

        await sendMessage(data.bot_token, chatId,
          `🎉 <b>KODE OTP DITERIMA!</b>

Kode: <code>${result.otp}</code>

📱 ${data.number}
🆔 <code>${data.order_id}</code>
🏷️ ${data.service}

Langsung pakai kode di atas! ✅`,
          keyboard([
            [{ text: '📱 Order Lagi', callback_data: 'otp' }, { text: '🏠 Menu', callback_data: 'menu' }]
          ])
        )

        // Notify owner
        const deployedBot = DeployedBots.getByBotId(data.bot_id)
        if (deployedBot) {
          const todayStats = OtpOrders.getTodayStats(data.bot_id)
          await sendMessage(data.bot_token, deployedBot.owner_id,
            `💰 <b>OTP TERJUAL!</b>

Layanan: ${data.service} ${data.country_flag}
Harga: ${formatRupiah(data.sell_price)}
Cost: ${formatRupiah(data.api_price)}
Profit: ${formatRupiah(data.profit)}
Pembeli: ${data.buyer_username ? `@${data.buyer_username}` : data.buyer_id}
Waktu: ${new Date().toLocaleString('id-ID')}

Total profit hari ini: ${formatRupiah(todayStats.total_profit)}`,
            keyboard([[{ text: '📊 Rekap', callback_data: 'rekap' }]])
          )
        }
      }
    } catch (e) {
      console.error('OTP check error:', e.message)
    }
  }, config.TIMEOUT.CHECK_INTERVAL)

  otpPolls.set(data.order_id, { intervalId, timeout })
}

function stopOtpPoll(orderId) {
  if (otpPolls.has(orderId)) {
    const { intervalId, timeout } = otpPolls.get(orderId)
    clearInterval(intervalId)
    clearTimeout(timeout)
    otpPolls.delete(orderId)
  }
}

// ==================== PAYMENT TIMEOUT HANDLER ====================
async function handlePaymentTimeout(mainBot, payment) {
  PendingPayments.update(payment.id, { status: 'expired' })

  const { type, data, chat_id, photo_message_id } = payment

  if (photo_message_id) {
    // Edit caption to timeout message
    const botToken = type === 'deploy' ? mainBot.token : data.bot_token
    await editCaption(botToken, chat_id, photo_message_id,
      `⏰ <b>WAKTU HABIS!</b>

Invoice dibatalkan otomatis.

Sudah bayar tapi kecancel?
Hubungi: @admin_username
Invoice ID: <code>${data.invoice_id}</code>`,
      keyboard([
        [{ text: '🚀 Deploy Lagi', callback_data: 'deploy' }, { text: '🏠 Menu', callback_data: 'menu' }]
      ])
    )
  }

  // Cancel OTP order if any
  if (type === 'otp' && data.order_id && data.api_key) {
    await cancelOrder(data.api_key, data.order_id)
    OtpOrders.update(data.otp_order_id, { status: 'cancelled' })
  }
}

// ==================== RESTORE PENDING CHECKS ON STARTUP ====================
export async function restorePendingChecks(mainBot) {
  const pending = PendingPayments.getPending()
  console.log(`Restoring ${pending.length} pending payment checks...`)
  for (const payment of pending) {
    if (new Date() < new Date(payment.expires_at)) {
      startPaymentCheck(mainBot, payment)
    } else {
      await handlePaymentTimeout(mainBot, payment)
    }
  }
}

export { startOtpPolling, stopCheck }
