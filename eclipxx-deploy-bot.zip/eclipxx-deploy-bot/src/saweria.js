// src/saweria.js
import axios from 'axios'
import config from '../config.js'

// ==================== LOGIN SAWERIA ====================
export async function loginSaweria(email, password) {
  try {
    const url = `${config.API.SAWERIA}/saweria`
    const response = await axios.get(url, {
      params: { email, password, apikey: config.ADMIN_SAWERIA.apikey }
    })

    if (response.data.status === true) {
      return {
        success: true,
        user_id: response.data.data.user_id,
        username: response.data.data.username,
        email: response.data.data.email
      }
    }
    return { success: false, message: 'Email/password salah' }
  } catch (error) {
    return { success: false, message: error.response?.data?.message || error.message }
  }
}

// ==================== CREATE PAYMENT ====================
export async function createPayment(userId, amount, message) {
  try {
    const url = `${config.API.SAWERIA}/saweria-create`
    const response = await axios.get(url, {
      params: { userid: userId, amount, message, apikey: config.ADMIN_SAWERIA.apikey }
    })

    if (response.data.status === true) {
      return {
        success: true,
        payment_id: response.data.data.id,
        amount: response.data.data.amount_raw,
        qr_string: response.data.data.qr_string,
        qr_image: response.data.data.qr_image,
        receipt_url: response.data.data.receipt,
        expired_at: response.data.data.expired_at,
        created_at: response.data.data.created_at
      }
    }
    return { success: false, message: 'Gagal membuat pembayaran' }
  } catch (error) {
    return { success: false, message: error.response?.data?.message || error.message }
  }
}

// ==================== CHECK PAYMENT ====================
export async function checkPayment(userId, paymentId) {
  try {
    const url = `${config.API.SAWERIA}/saweria-check`
    const response = await axios.get(url, {
      params: { userid: userId, id: paymentId, apikey: config.ADMIN_SAWERIA.apikey }
    })

    if (response.data.status === true) {
      return {
        success: true,
        paid: true,
        payment_id: response.data.data.id,
        amount: response.data.data.amount,
        message: response.data.data.message,
        paid_at: response.data.data.paid_at
      }
    }
    return { success: true, paid: false, message: response.data.message }
  } catch (error) {
    return { success: false, paid: false, message: error.response?.data?.message || error.message }
  }
}

// ==================== GENERATE QR BASE64 IMAGE ====================
// Mengubah qr_image base64 menjadi Buffer untuk dikirim ke Telegram
export function parseQrImage(qrImageBase64) {
  if (!qrImageBase64) return null
  // Format: "data:image/png;base64,iVBORw0KGgo..."
  const base64Data = qrImageBase64.replace(/^data:image\/\w+;base64,/, '')
  return Buffer.from(base64Data, 'base64')
}
