// index.js - ENTRY POINT
/**
 * EclipxxDeployBot - Main Entry Point
 * 
 * Cara run:
 * node index.js
 * 
 * Atau dengan PM2:
 * pm2 start index.js --name eclipxx-bot
 */

import './src/database.js' // Init database
import config from './config.js'
import { DeployedBots } from './src/database.js'
import { startDeployedBot } from './src/deployedBot.js'
import { restorePendingChecks } from './src/paymentManager.js'
import { startScheduler } from './src/scheduler.js'

console.log('🚀 Starting EclipxxDeployBot...')
console.log(`📅 ${new Date().toLocaleString('id-ID')}`)

// ==================== MAIN BOT ====================
const { default: mainBot } = await import('./src/mainBot.js')

// ==================== START ALL DEPLOYED BOTS ====================
const activeBots = DeployedBots.getAll(1000, 0).filter(b => b.status === 'active')
console.log(`\n🤖 Starting ${activeBots.length} deployed bot(s)...`)

const runningBots = new Map()

for (const botRecord of activeBots) {
  try {
    // Check if expired
    if (new Date() > new Date(botRecord.expired_at)) {
      DeployedBots.update(botRecord.id, { status: 'expired' })
      console.log(`⏰ Bot @${botRecord.bot_username} expired, skipping...`)
      continue
    }

    // Check if limit habis
    if (botRecord.response_used >= botRecord.response_limit) {
      console.log(`⚠️ Bot @${botRecord.bot_username} limit habis`)
      // Still start but won't respond to users
    }

    const bot = startDeployedBot(botRecord)
    runningBots.set(botRecord.bot_id, bot)
    console.log(`✅ @${botRecord.bot_username} started`)
    
    // Small delay to avoid rate limits
    await new Promise(r => setTimeout(r, 500))
  } catch (e) {
    console.error(`❌ Failed to start @${botRecord.bot_username}:`, e.message)
  }
}

// ==================== RESTORE PENDING PAYMENTS ====================
console.log('\n💳 Restoring pending payments...')
await restorePendingChecks({ token: config.MAIN_BOT.TOKEN })

// ==================== START SCHEDULER ====================
console.log('\n⏰ Starting scheduler...')
startScheduler(config.MAIN_BOT.TOKEN)

// ==================== HANDLE NEW DEPLOYS ====================
// Listen for new bots to start (from payment success)
// In production, you might use a queue or event system
// For simplicity, we poll for new active bots
setInterval(async () => {
  const currentBots = DeployedBots.getAll(1000, 0).filter(b => b.status === 'active')
  
  for (const botRecord of currentBots) {
    if (!runningBots.has(botRecord.bot_id)) {
      // Check if expired
      if (new Date() > new Date(botRecord.expired_at)) {
        DeployedBots.update(botRecord.id, { status: 'expired' })
        continue
      }

      try {
        console.log(`🆕 Starting new bot @${botRecord.bot_username}...`)
        const bot = startDeployedBot(botRecord)
        runningBots.set(botRecord.bot_id, bot)
      } catch (e) {
        console.error(`❌ Failed to start @${botRecord.bot_username}:`, e.message)
      }
    }
  }

  // Stop bots that are no longer active
  for (const [botId, bot] of runningBots.entries()) {
    const record = DeployedBots.getByBotId(botId)
    if (!record || record.status !== 'active') {
      try {
        bot.stopPolling()
        runningBots.delete(botId)
        console.log(`🛑 Stopped bot ${botId}`)
      } catch (e) { /* ignore */ }
    }
  }
}, 30000) // Check every 30 seconds

// ==================== GRACEFUL SHUTDOWN ====================
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down...')
  mainBot.stopPolling()
  for (const bot of runningBots.values()) {
    try { bot.stopPolling() } catch { /* ignore */ }
  }
  process.exit(0)
})

process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error)
})

process.on('unhandledRejection', (reason) => {
  console.error('Unhandled Rejection:', reason)
})

console.log('\n✅ EclipxxDeployBot is running!')
console.log('📊 Dashboard tersedia via /admin command\n')
